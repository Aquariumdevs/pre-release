#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str


# Function to build request for paths
def get_request_for_paths(state):
    height = state.get("prev_height_value")
    if height is None:
        raise ValueError("prev_height_value is missing in state")

    # Convert to an 8-byte big-endian hex string
    height_hex = format(height, '016x')  # 16 hex digits = 8 bytes
    request_key = height_hex + "00"

    return request_key

# Function to retrieve paths
def query_path():
    state = load_wallet_state()

    # Query for paths using the 4-byte address
    try:
        query_output = call_go_wallet("query", [get_request_for_paths(state)])
        path_bytes = query_output.strip('[]').split()

        print(len(path_bytes))

        if len(path_bytes) > 72:  # Ensure valid response length
            index = 0

            # Extract key (8 bytes)
            key2 = path_bytes[index:index + 8]
            index += 8

            # Extract blockhashroot (32 bytes)
            # blockhashroot = path_bytes[index:index + 32]
            index += 32

            # Extract blockhashroot (78 bytes)
            blockhashroot_path_bytes = path_bytes[index:index + 78]
            index += 78

            # Convert the first 78 ASCII bytes to a string
            blockhashroot = "".join(chr(int(byte)) for byte in blockhashroot_path_bytes[:78])


            # Extract blockhashroot path length (1 byte)
            blockhashroot_length = int(path_bytes[index], 10)
            index += 1

            # Extract blockhashroot path hashes (M * 32 bytes)
            blockhashroot_path_bytes = path_bytes[index:index + (blockhashroot_length * 78)]
            index += (blockhashroot_length * 78)


            # Convert ASCII bytes to strings
            blockhashroot_path = [
                "".join(chr(int(byte)) for byte in blockhashroot_path_bytes[i:i+78])
                for i in range(0, len(blockhashroot_path_bytes), 78)
            ]


            print(f"path_bytes: {path_bytes}")
            print(f"index: {index}")
            print(f"Key2: {key2}")
            print(f"Blockhashroot: {blockhashroot}")
            print(f"Blockhashroot Path Length: {blockhashroot_length}")
            print(f"Blockhashroot Path: {blockhashroot_path}")

            # Validate extracted lengths
            if index > len(path_bytes):
                raise ValueError("Path response is incomplete or incorrectly formatted.")

            state['pre_path_query_key2'] = key2
            state['pre_blockhashroot'] = blockhashroot
            state['pre_blockhashroot_length'] = blockhashroot_length
            state['pre_blockhashroot_path'] = blockhashroot_path

            # Save the updated state
            save_wallet_state(state)




        else:
            print("Failed to retrieve a valid path. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query path information: {e}")


if __name__ == "__main__":
    query_path()

