#!/bin/bash

# Ensure the script stops on the first error
set -e

CGO_CFLAGS="-O -D__BLST_PORTABLE__"
CGO_CFLAGS_ALLOW="-O -D__BLST_PORTABLE__"
export CGO_CFLAGS
export CGO_CFLAGS_ALLOW

# Set up Go environment variables
export GOPATH=$HOME/go
export PATH=$PATH:/usr/local/go/bin:$GOPATH/bin

# Change to the directory containing the Go application source code
cd $HOME/go/apps/wallet

# Initialize the module (if not already done)
if [ ! -f "go.mod" ]; then
    go mod init wallet
fi

# Tidy up the dependencies
go mod tidy

# Build the application
go build

