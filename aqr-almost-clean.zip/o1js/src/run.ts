import { fieldArray, Wallet, transitionProgram, MyPublicOutputs, hashInputs, MerkleWitness4, FastTree, MyProof } from './transition.js';
import { Bool, Bytes, Field, Gadgets, MerkleMap, MerkleMapWitness, verify, Poseidon, VerificationKey, MerkleTree, Proof } from 'o1js';
import { spawn } from 'child_process';
import * as fs from 'fs';
import * as readline from 'readline';

class Bytes32 extends Bytes(32) {}

//redeclaration

function stepSimple(xsInLeft: Field, xsInRight: Field, xsOutL: Field, xsOutR: Field) {
  const lhash = Poseidon.hash([xsInLeft, xsInRight]);
  const rhash = Poseidon.hash([xsInRight, xsInLeft]);
/*  console.log(`🎯 Expected lhash: ${lhash.toString()}`);
  console.log(`🎯 Expected rhash: ${rhash.toString()}`);*/

  const leftL = xsOutL.equals(lhash)
  const rightL = xsOutL.equals(rhash)
  const leftR = xsOutR.equals(lhash)
  const rightR = xsOutR.equals(rhash)
/*  console.log(`✅ left presence check result: ${leftL.toBoolean()}`);
  console.log(`✅ right presence check result: ${rightL.toBoolean()}`);
  console.log(`✅ left presence check result: ${leftR.toBoolean()}`);
  console.log(`✅ right presence check result: ${rightR.toBoolean()}`);*/

  leftL.or(rightL.or(leftR.or(rightR))).assertEquals(true);
}

function verifyMerklePath(leaf: Field, expectedRoot: Field, merklePath: Field[]) {
  console.log("\n🔍 Starting Merkle Path Verification...");
  console.log(`🌿 Leaf: ${leaf.toString()}`);
  console.log(`🎯 Expected Root: ${expectedRoot.toString()}`);
  console.log(`🛤️ Merkle Path Length: ${merklePath.length}`);

  let rootFound = Bool(false);
  let rootExists = Bool(false);

  console.log("\n🔎 Checking if the leaf exists in the first two nodes of the Merkle path...");
  const leafCheck = (merklePath[0].equals(leaf)).or(merklePath[1].equals(leaf));
  console.log(`✅ Leaf presence check result: ${leafCheck.toBoolean()}`);
  leafCheck.assertEquals(true);
  rootExists = merklePath[0].equals(expectedRoot);
  console.log(`   🧐 Root check at index ${0}: ${rootExists.toBoolean() ? "✅ Match found" : "❌ No match"}`);

  console.log("\n🔄 Iterating through Merkle path...");
  for (let i = 0; i < 125; i += 2) {
/*    console.log(`\n🔹 Processing nodes at indices [${i}], [${i+1}], [${i+2}]`);
    console.log(`   🔢 merklePath[${i}]: ${merklePath[i].toString()}`);
    console.log(`   🔢 merklePath[${i+1}]: ${merklePath[i+1].toString()}`);*/

    stepSimple(merklePath[i], merklePath[i+1], merklePath[i+2], merklePath[i+3]);

    //console.log(`   🔗 Computed merklePath[${i+2}]: ${merklePath[i+2].toString()}`);

    rootFound = merklePath[i+2].equals(expectedRoot);
    console.log(`   🧐 Root check at index ${i+2}: ${rootFound.toBoolean() ? "✅ Match found" : "❌ No match"}`);

    rootExists = rootExists.or(rootFound);
  }

  console.log("\n✅ Final root validation...");
  console.log(`   🔎 Root exists: ${rootExists.toBoolean()}`);
  rootExists.assertEquals(true);

  console.log("🎉 Merkle Path verification successful! The computed root matches the expected root.");
}

// Helper function to generate a random Field value
function randomField(): Field {
  return new Field(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));
}

// Function to simulate a Merkle path
function simulateMerklePaths(leaf1: Field, leaf2: Field, depth: number = 128): fieldArray {
  let path = [leaf1];
  const right = leaf2;

  for (let i = 0; i < 128; i += 2) {
    const left = path[i];
    let right = Field("60"); // Simulating a paired node
    if(i == 0) {
      right = leaf2;
    }
    path.push(right);
    const hash = treeHasher.createMerkleTree([left, right]);
    path.push(hash);
  }

  // The last hash is the root
  return new fieldArray({ array: path });
}

function simulateMerklePath(leaf: Field, depth: number = 128): fieldArray {
  let path = [leaf];

  for (let i = 0; i < 128; i += 2) {
    const left = path[i];
    const right = new Field("60");  // Simulating a paired node
    path.push(right);
    const hash = treeHasher.createMerkleTree([left, right]);
    path.push(hash);
  }

  // The last hash is the root
  return new fieldArray({ array: path });
}

let verificationKey: VerificationKey; // Declare the variable to store the verification key

async function testRandomInitialization() {
  // Create a random balance and initial block hash
  const balance = Field(0);

  // Initialize the wallet with random balance
  const wallet = new Wallet(balance);
  wallet.balance = Field(0);

  // Assign random values to other necessary fields
  const blsPublicKeyPart1 = randomField();
  const blsPublicKeyPart2 = randomField();

  wallet.pkHash = randomField();
  wallet.address = randomField();

  const stateHash = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balance, wallet.inTxsRootNew, wallet.outTxsRoot]);
  const messageHash = treeHasher.createMerkleTree([wallet.address, wallet.pkHash, stateHash]);
  console.log(`message hash: ${messageHash.toString()}`);

  // Prepare Merkle paths
  const msgInclusionPath = simulateMerklePath(messageHash);

  const initialBlockHash = msgInclusionPath.array[msgInclusionPath.array.length - 3];
  wallet.blockHash = initialBlockHash; // Set the initial block hash as the leaf of the Merkle path

  const myPublicOutputs = new MyPublicOutputs({
    Leaf: initialBlockHash, // The initial block hash is the leaf
    Root: msgInclusionPath.array[msgInclusionPath.array.length - 3] // one of the last elements is the root
  });

  // Call the initialize state and prove method
  const result = await wallet.initializeStateAndProve(
    blsPublicKeyPart1,
    blsPublicKeyPart2,
    msgInclusionPath,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);

  return wallet;
}


async function testDeriveDestination(wallet: Wallet) {

  const stateHashPrev = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balanceNew, wallet.inTxsRootNew, wallet.outTxsRoot]);

  const pkSaltHash = randomField();
  const messageHash = wallet.deriveDestination(pkSaltHash);

  const inclusionPath = wallet.path;
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // The initial block hash is the leaf
    Root: inclusionPath.array[inclusionPath.array.length - 3] // The last element is the root
  });

  const msgInclusionPath = simulateMerklePaths(messageHash, myPublicOutputs.Root);

  wallet.blockHash = msgInclusionPath.array[msgInclusionPath.array.length - 3]; // The last element is the root

  // Call the function that wraps the zk-program call
  const result = await wallet.proveStateAfterDestinationDerivation(
    pkSaltHash,
    msgInclusionPath, // prev
    msgInclusionPath,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);
}

async function testBurnToStealth(wallet: Wallet) {
  // Store a snapshot of the current state before making changes

  const stateHashPrev = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balanceNew, wallet.inTxsRootNew, wallet.outTxsRoot]);

  const amount = Field("10");
  const messageHash = wallet.increaseStealthFunds(amount);

  // Prepare Merkle paths
  const inclusionPath = wallet.path;
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // The initial block hash is the leaf
    Root: inclusionPath.array[inclusionPath.array.length - 3] // The last element is the root
  });

  const msgInclusionPath = simulateMerklePaths(messageHash, myPublicOutputs.Root);

  wallet.blockHash = msgInclusionPath.array[msgInclusionPath.array.length - 3]; // The last element is the root

  // Call the function that wraps the zk-program call
  const result = await wallet.proveFundsBurning(
    amount,
    msgInclusionPath, // prev
    msgInclusionPath,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);
}

async function testSendTx(wallet: Wallet) {
  // Store a snapshot of the current state before making changes

  const stateHashPrev = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balanceNew, wallet.inTxsRootNew, wallet.outTxsRoot]);

  const destination = wallet.Destinations[0];
  const amount = Field("5");
  const salt = wallet.destinationsRoot; // this should be changed

  const messageHash = wallet.constructNewTx(destination, amount, salt);

  // Prepare Merkle paths
  const inclusionPath = wallet.path;
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // The initial block hash is the leaf
    Root: inclusionPath.array[inclusionPath.array.length - 3] // The last element is the root
  });

  const msgInclusionPath = simulateMerklePaths(messageHash, myPublicOutputs.Root);
  wallet.blockHash = msgInclusionPath.array[msgInclusionPath.array.length - 3]; // The last element is the root

  // Call the function that wraps the zk-program call
  const result = await wallet.proveStateAfterSending(
    salt,
    msgInclusionPath, // prev
    msgInclusionPath,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);

  const proofInclusionPath = simulateMerklePaths(wallet.blockHash, salt);
  const blockHash = proofInclusionPath.array[proofInclusionPath.array.length - 3]; // The last element is the root

  // Call the function that wraps the zk-program call
  const result2 = await wallet.proveTxAfterSending(
    blockHash,
    salt,
    proofInclusionPath, // prev
    myPublicOutputs
  );

  const isValid2 = await verify(result2.toJSON(), verificationKey);
  console.log('ok', isValid2);
}

async function testAbsorbTx(wallet: Wallet) {
  // Random initialization values for testing
  const amount = Field("5");
  const salt = wallet.destinationsRoot; // this should be changed

  const transactionDestination = wallet.Destinations[0];
  const transactionBalance = wallet.balance.sub(wallet.balanceNew);
  console.log('transactionBalance of absorbing transaction:', transactionBalance.toString());

  // Simulate storing the previous state before the transaction
  const stateHashPrev = treeHasher.createMerkleTree([
    wallet.pkHash,
    wallet.address,
    wallet.destinationsRoot,
    wallet.balanceNew,
    wallet.inTxsRootNew,
    wallet.outTxsRoot
  ]);

  // Call the absorbNewTx function
  if (!wallet.absorbNewTx(transactionDestination, amount, salt, wallet.newTxProof)) {
    return;
  }

  const newStateHash = wallet.stateHashNew;
  const messageHash = treeHasher.createMerkleTree([wallet.address, wallet.stateHashNew]);

  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // Using the initial state hash as the leaf
    Root: wallet.blockHash // The last element is the root
  });

  // For verification purposes, simulate the transaction inclusion proof
  const inclusionPath = simulateMerklePaths(wallet.blockHash, messageHash);
  wallet.blockHash = inclusionPath.array[inclusionPath.array.length - 3]; // The last element is the root

  console.log('wallet.blockHash:', wallet.blockHash.toString());
  console.log('messageHash:', messageHash.toString());

  // Call the function that wraps the zk-program call for verifying the new state
  const result = await wallet.proveStateAfterAbsorbing(
    transactionDestination,
    transactionBalance,
    salt,
    inclusionPath, // Using the same path for simplicity
    inclusionPath, // New path after the transaction is absorbed
    wallet.oldStateSnapshot!.newTxProof,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);
}

const treeHasher = new FastTree();

async function runAllTests() {
  console.log('compiling zkprogram...');
  console.time('compile');

  // Run the function to check, load or create the verification key
  const compiled = await transitionProgram.compile();
  verificationKey = compiled.verificationKey;
  console.timeEnd('compile');

  console.log('testing init...');
  console.time('init');
  const wal = await testRandomInitialization();
  console.timeEnd('init');
  console.log('finished init...');

  console.log('testing derive...');
  console.time('derive');
  await testDeriveDestination(wal);
  console.timeEnd('derive');
  console.log('finished derive...');

  console.log('testing BurnToStealth...');
  console.time('BurnToStealth');
  await testBurnToStealth(wal);
  console.timeEnd('BurnToStealth');
  console.log('finished BurnToStealth...');

  console.log('testing send...');
  console.time('send');
  await testSendTx(wal);
  console.timeEnd('send');
  console.log('finished send...');

  console.log('testing receive...');
  console.time('receive');
  await testAbsorbTx(wal);
  console.timeEnd('receive');
  console.log('finished receive...');
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

// Function to call a Python script with interactive input
function callPythonScript(script: string, args: string[] = []): Promise<void> {
  return new Promise((resolve, reject) => {
    const process = spawn('python3', [script, ...args], {
      stdio: ['pipe', 'inherit', 'inherit']
    });

    rl.on('line', (input) => {
      process.stdin.write(input + '\n');
    });

    process.on('close', (code) => {
      rl.removeAllListeners('line');
      if (code !== 0) {
        reject(new Error(`Python script exited with code ${code}`));
      } else {
        resolve();
      }
    });
  });
}

// Function to wrap rl.question in a promise
function question(query: string): Promise<string> {
  return new Promise(resolve => rl.question(query, resolve));
}
async function callScript(script: string): Promise<boolean> {
  try {
    await callPythonScript(script);
    return true;
  } catch (error) {
    console.error(`\nScript failed: ${script}\nError:`, error);
    return false;
  }
}

async function showBalance() {
  await callScript('show_balance.py');
}

async function transferFunds() {
  await callScript('transfer.py');
}

async function stakeFunds() {
  await callScript('stake.py');
}

async function unstakeFunds() {
  await callScript('unstake.py');
}

async function deleteWallet() {
  const success = await callScript('delete_wallet.py');
  if (success) {
    console.log("\nExiting after deletion as no operations can be performed on a deleted wallet");
    rl.close();
  }
}

async function fundNewWallet() {
  await callScript('sponsor_create_account.py');
}

async function initializeHiddenState() {
  if (!(await callScript('initialize_hidden_state.py'))) return;
  await initialize_hid_state_vals("wallet_state.json");
  try {
    await calc_state_hash("wallet_state.json");
  } catch (error) {
    console.error("Poseidon error:", error);
    return;
  }
  if (!(await callScript('update_state_hash.py'))) return;
  if (!(await callScript('query_paths.py'))) return;

  const wal = await hiddenStateInitializationFromJson("wallet_state.json");
  await initDeriveDestination(wal, "wallet_state.json");

  if (!(await callScript('update_state_hash.py'))) return;
  if (!(await callScript('query_paths.py'))) return;
  if (!(await callScript('query_path.py'))) return;

  await proveDeriveDestination(wal, "wallet_state.json");
}

async function sendStealthTransaction() {
  await callScript('send_stealth.py');
}

async function receiveStealthTransaction() {
  await callScript('receive_stealth.py');
}

async function showStealthAddresses() {
  await callScript('show_stealth_addresses.py');
}

async function showStealthBalance() {
  await callScript('show_stealth_balance.py');
}

async function transferToStealth() {
  await callScript('prepare_transfer_with_burn_to_stealth.py');
  const walb = await moveToStealth("wallet_state.json");
  if (!walb) return;
  await callScript('transfer_with_burn_to_stealth.py');
  if (!(await callScript('query_paths.py'))) return;
  if (!(await callScript('query_path.py'))) return;
  await proveBurnToStealth(walb, "wallet_state.json");
}

async function initializeWalletSponsor() {
  await callScript('initialize_wallet_sponsor.py');
}

async function initializeWalletClient() {
  await callScript('initialize_wallet_client.py');
}

async function updateStateHash() {
  await callScript('update_state_hash.py');
}

async function queryPaths() {
  if (!(await callScript('query_paths.py'))) return;
  await processAndVerifyMerklePaths("wallet_state.json");
}

async function deriveDestinationAndProve() {
  const wald = await deriveDestination("wallet_state.json");
  if (!wald) return;
  if (!(await callScript('update_state_hash.py'))) return;
  if (!(await callScript('query_paths.py'))) return;
  if (!(await callScript('query_path.py'))) return;
  await proveDeriveDestination(wald, "wallet_state.json");
}

async function interactive() {
  try {
    await callScript('show_keys.py');
    await showBalance();

    while (true) {
      console.log("\nWallet Operations:");
      console.log("1. Show Balance");
      console.log("2. Transfer Funds");
      console.log("3. Stake Funds");
      console.log("4. Unstake Funds");
      console.log("5. Delete Wallet");
      console.log("6. Fund New Wallet");
      console.log("7. Initialize Hidden State");
      console.log("8. Send Stealth Transaction");
      console.log("9. Receive Stealth Transaction");
      console.log("10. Show Stealth Addresses");
      console.log("11. Show Stealth Balance");
      console.log("12. Transfer to Stealth");
      console.log("13. Run Zk func Tests");
      console.log("14. Initialize Wallet (Sponsor)");
      console.log("15. Initialize Wallet (Client)");
      console.log("16. Update wallet state hash on chain");
      console.log("17. Query Paths");
      console.log("18. Derive Destination and Prove");
      console.log("x. Exit");

      const choice = await question("Select an operation: ");

      try {
        switch (choice) {
          case '1':
            await showBalance();
            break;
          case '2':
            await transferFunds();
            break;
          case '3':
            await stakeFunds();
            break;
          case '4':
            await unstakeFunds();
            break;
          case '5':
            await deleteWallet();
            return;
          case '6':
            await fundNewWallet();
            break;
          case '7':
            await initializeHiddenState();
            break;
          case '8':
            await sendStealthTransaction();
            break;
          case '9':
            await receiveStealthTransaction();
            break;
          case '10':
            await showStealthAddresses();
            break;
          case '11':
            await showStealthBalance();
            break;
          case '12':
            await transferToStealth();
            break;
          case '13':
            await runAllTests();
            break;
          case '14':
            await initializeWalletSponsor();
            break;
          case '15':
            await initializeWalletClient();
            break;
          case '16':
            await updateStateHash();
            break;
          case '17':
            await queryPaths();
            break;
          case '18':
            await deriveDestinationAndProve();
            break;
          case 'x':
          case 'X':
            console.log("\nExiting wallet application.");
            rl.close();
            return;
          default:
            console.log("\nInvalid choice, please select a valid operation.");
        }
      } catch (error) {
        console.error('\nError:', error);
      }
    }
  } catch (error) {
    console.error('\nInitialization Error:', error);
  }
}


// Function to read and parse JSON data
function loadMerklePathFromJson(filePath: string) {
  console.log(`\n📂 Loading JSON from: ${filePath}`);
  try {
    const rawData = fs.readFileSync(filePath, 'utf8');
    const parsedData = JSON.parse(rawData);
    console.log("✅ Successfully loaded JSON.");
    return parsedData;
  } catch (error) {
    console.error("❌ Error reading JSON file:", error);
    return null;
  }
}

function bytesToField(byteArray: string[], label: string): Field {
  // Convert each string element to a number
  const byteNumbers = byteArray.map(b => parseInt(b, 10));

  // Ensure we only pass max 32 bytes at a time
  if (byteNumbers.length > 32) {
    console.error(`⚠️ Error: ${label} has more than 32 bytes! Splitting required.`);
    throw new Error("Field.fromBytes() requires at most 32 bytes.");
  }

  // Convert to Field
  const fieldValue = Field.fromBytes(byteNumbers);
  console.log(`🔢 Converted ${label} to Field:`, fieldValue.toString());

  return fieldValue;
}



function calc_state_hash(jsonFilePath: string): string | null {
  let data = loadMerklePathFromJson(jsonFilePath);
  if (!data) {
    console.error("Failed to load JSON data");
    return null;
  }

  console.log("\n🔍 Reading wallet state from JSON...");

  // Read values directly from JSON
  const state = {
    pkHash: new Field(data.pkHash),//////FIXME
    address: new Field(data.addressdec),////FIXME
    destinationsRoot: new Field(data.destinationsRoot),
    balance: new Field(data.Balance),
    inTxsRootNew: new Field(data.hidden_input_txs),
    outTxsRoot: new Field(data.hidden_output_txs),
  };

  // Compute state hash
  const stateHash = treeHasher.createMerkleTree([
    state.pkHash,
    state.address,
    state.destinationsRoot,
    state.balance,
    state.inTxsRootNew,
    state.outTxsRoot,
  ]).toString();

  console.log("✅ Computed State Hash:", stateHash);

  // Store stateHash in JSON
  data.state_hash = stateHash;
  try {
    fs.writeFileSync(jsonFilePath, JSON.stringify(data, null, 2));
    console.log("✅ State Hash saved to JSON file!");
  } catch (error) {
    console.error("❌ Error writing to JSON file:", error);
    return null;
  }

  return stateHash;
}

// Function to construct Merkle paths from JSON with logging
function constructMerklePathFromJson(jsonFilePath: string) {
  const data = loadMerklePathFromJson(jsonFilePath);
  if (!data) return null;

  console.log("\n🔍 Parsing Merkle Path Data...");

  const blockhashroot = new Field(data.pre_blockhashroot);
  console.log(`✅ Imported blockhashroot: ${blockhashroot.toString()}`);

  console.log("\n📜 Parsing blockhashroot_path...");
  const blockhashrootPath: Field[] = data.pre_blockhashroot_path.map((decimalString: string, index: number) => {
    const field = new Field(decimalString);
    console.log(`✅ Imported blockhashroot_path[${index}]: ${field.toString()}`);
    return field;
  });


  console.log("\n✅ Successfully parsed Merkle paths!\n");
  return { blockhashrootPath, blockhashroot };
}

// Function to construct Merkle paths from JSON with logging
function constructMerklePathsFromJson(jsonFilePath: string) {
  const data = loadMerklePathFromJson(jsonFilePath);
  if (!data) return null;

  console.log("\n🔍 Parsing Merkle Path Data...");

  const blockroot = new Field(data.blockroot);
  const blockhashroot = new Field(data.blockhashroot);
  console.log(`✅ Imported blockroot: ${blockroot.toString()}`);
  console.log(`✅ Imported blockhashroot: ${blockhashroot.toString()}`);

  console.log("\n📜 Parsing blockroot_path...");
  const blockrootPath: Field[] = data.blockroot_path.map((decimalString: string, index: number) => {
    const field = new Field(decimalString);
    console.log(`✅ Imported blockroot_path[${index}]: ${field.toString()}`);
    return field;
  });

  console.log("\n📜 Parsing blockhashroot_path...");
  const blockhashrootPath: Field[] = data.blockhashroot_path.map((decimalString: string, index: number) => {
    const field = new Field(decimalString);
    console.log(`✅ Imported blockhashroot_path[${index}]: ${field.toString()}`);
    return field;
  });


  console.log("\n✅ Successfully parsed Merkle paths!\n");
  return { blockrootPath, blockhashrootPath, blockroot, blockhashroot };
}

// Function to create the final Merkle path
function generateMerklePath(leaf: Field, path: Field[]): Field[] {
  console.log("\n🌿 Generating Merkle Path...");
  let currentHash = leaf;
  const computedPath: Field[] = [leaf];

  for (let i = 0; i < path.length; i++) {
    const right = path[i];
    console.log(`🔄 Hashing node ${i}:`, currentHash.toString(), "+", right.toString());

    currentHash = treeHasher.createMerkleTree([currentHash, right]);
    console.log(`🔄 Hash result ${i}:`, currentHash.toString());

    computedPath.push(right);
    computedPath.push(currentHash);
  }

  console.log("✅ Merkle Path Generated!\n");
  return computedPath;
}



// Main function to process and verify Merkle paths
function processAndVerifyMerklePaths(jsonFilePath: string) {
  const paths = constructMerklePathsFromJson(jsonFilePath);
  if (!paths) {
    console.error("Failed to process Merkle paths.");
    return;
  }

  const leaf = new Field("0");  // Example leaf, replace with actual data if needed

  // Generate the Merkle paths
  const blockrootMerklePath = paths.blockrootPath;
  const blockhashrootMerklePath = paths.blockhashrootPath;


  // Append blockhashroot to the Merkle path
  blockhashrootMerklePath.push(paths.blockhashroot);
  blockhashrootMerklePath.push(paths.blockhashroot);

  // Append blockroot to the Merkle path
  blockrootMerklePath.push(paths.blockroot);
  blockrootMerklePath.push(paths.blockroot);

  let h = paths.blockroot;
  let j = paths.blockhashroot;
  for (let i = 0; i < 127; i++) { //TODO split and adjust to length of paths
    h = Poseidon.hash([h, h]);
    blockrootMerklePath.push(h);
    blockrootMerklePath.push(h);
    j = Poseidon.hash([j, j]);
    blockhashrootMerklePath.push(j);
    blockhashrootMerklePath.push(j);
  }
  console.log("Blockhashroot Merkle Path Verification...");

  // Verify the paths
  const firstHash = blockrootMerklePath[0];
  const blockrootValid = verifyMerklePath(firstHash, paths.blockroot, blockrootMerklePath);
  const firstHash2 = blockhashrootMerklePath[0];
  const blockhashrootValid = verifyMerklePath(firstHash2, paths.blockhashroot, blockhashrootMerklePath);

  console.log("✅ Valid");

}


// ==============================
// Utility Functions
// ==============================

function fillMissingDefaults(data: any, defaults: any): any {
  return {
    ...data,
    addressdec: data.addressdec ?? defaults.addressdec,
    pkHash: data.pkHash ?? defaults.pkHash,
    destinationsRoot: data.destinationsRoot ?? defaults.destinationsRoot,
    Balance: data.Balance ?? defaults.Balance,
    hidden_input_txs: data.hidden_input_txs ?? defaults.hidden_input_txs,
    hidden_output_txs: data.hidden_output_txs ?? defaults.hidden_output_txs
  };
}

function mergeMerklePaths(paths: any): Field[] {
  const merged = [...paths.blockrootPath, ...paths.blockhashrootPath, paths.blockhashroot, paths.blockhashroot];
  return merged;
}

function extendMerklePath(path: Field[], baseHash: Field, levels: number = 127): Field[] {
  let h = baseHash;
  for (let i = 0; i < levels; i++) {
    h = Poseidon.hash([h, h]);
    path.push(h, h);
  }
  return path;
}

function parseBLSPublicKey(hexKey: string): [Field, Field] {
  const bytes1 = Bytes32.fromHex(hexKey.substring(0, 32));
  const bytes2 = Bytes32.fromHex(hexKey.substring(32, 64));
  return [
    Field.fromBytes(Array.from(bytes1.toBytes())),
    Field.fromBytes(Array.from(bytes2.toBytes()))
  ];
}

function buildStateFromJson(data: any): any {
  console.log("DEBUG fields from JSON:");
  console.log("pkHash:", data.pkHash);
  console.log("addressdec:", data.addressdec);
  console.log("destinationsRoot:", data.destinationsRoot);
  console.log("hidden_input_txs:", data.hidden_input_txs);
  console.log("hidden_output_txs:", data.hidden_output_txs);
  //console.log("blockHash:", data.blockHash);

  return {
    pkHash: new Field(data.pkHash),
    address: new Field(data.addressdec),
    destinationsRoot: new Field(data.destinationsRoot),
    balance: new Field(data.Balance),
    inTxsRootNew: new Field(data.hidden_input_txs),
    outTxsRoot: new Field(data.hidden_output_txs)
  };
}

// ==============================
// Main Functions
// ==============================

export async function initialize_hid_state_vals(jsonFilePath: string): Promise<void> {
  let data = loadMerklePathFromJson(jsonFilePath);
  if (!data) {
    console.error("Failed to load JSON data");
    return;
  }

  console.log("\n🛠️ Initializing missing state parameters...");

  const pkHash = 0;//TODO

  const defaults = {
    addressdec: 0,
    pkHash: pkHash,
    destinationsRoot: "544619463418997333856881110951498501703454628897449993518845662251180546746",
    Balance: 0,
    hidden_input_txs: "22731122946631793544306773678309960639073656601863129978322145324846701682624",
    hidden_output_txs: "544619463418997333856881110951498501703454628897449993518845662251180546746",
  };

  data = fillMissingDefaults(data, defaults);

  try {
    fs.writeFileSync(jsonFilePath, JSON.stringify(data, null, 2));
    console.log("✅ JSON state initialized successfully!");
  } catch (error) {
    console.error("❌ Error writing to JSON file:", error);
  }

  try {
    await callPythonScript('query_decimal.py');
  } catch (error) {
    console.error("Error querying dec:", error);
    return;
  }
}

export async function hiddenStateInitializationFromJson(jsonFilePath: string) {
  const balance = new Field(0);
  const wallet = new Wallet(balance);
  const data = loadMerklePathFromJson(jsonFilePath);

  if (!data) {
    console.error("Failed to load JSON data");
    return wallet;
  }

  const state = buildStateFromJson(data);

  const stateHash = treeHasher.createMerkleTree([
    state.pkHash,
    state.address,
    state.destinationsRoot,
    state.balance,
    state.inTxsRootNew,
    state.outTxsRoot,
  ]);

  const messageHash = treeHasher.createMerkleTree([state.address, stateHash]);
  console.log(`message hash: ${messageHash.toString()}`);

  const paths = constructMerklePathsFromJson(jsonFilePath);
  if (!paths) {
    console.error("Failed to process Merkle paths.");
    return wallet;
  }

  let mergedMerklePath = mergeMerklePaths(paths);
  mergedMerklePath = extendMerklePath(mergedMerklePath, paths.blockhashroot);

  verifyMerklePath(messageHash, paths.blockhashroot, mergedMerklePath);
  console.log("✅ Valid Merged Merkle Path");

  wallet.balance = balance;
  wallet.pkHash = new Field(data.pkHash);
  wallet.address = new Field(data.addressdec);
  wallet.destinationsRoot = state.destinationsRoot;
  wallet.inTxsRootNew = state.inTxsRootNew;
  wallet.outTxsRoot = state.outTxsRoot;
  wallet.blockHash = new Field(paths.blockhashroot);
  wallet.stateHashNew = stateHash;

  const [blsPublicKeyPart1, blsPublicKeyPart2] = parseBLSPublicKey(data.bls_public_key);

  const myPublicOutputs = new MyPublicOutputs({
    Leaf: wallet.blockHash,
    Root: wallet.blockHash
  });

  wallet.path = new fieldArray({ array: mergedMerklePath });

  const compiled = await transitionProgram.compile();
  const verificationKey = compiled.verificationKey;

  const result = await wallet.initializeStateAndProve(
    blsPublicKeyPart1,
    blsPublicKeyPart2,
    wallet.path,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);

  if (isValid) {
    fs.writeFileSync(jsonFilePath, JSON.stringify({ ...data, proof: result.toJSON() }, null, 2));
    console.log("✅ Proof stored in JSON file");
  }

  return wallet;
}

export async function initDeriveDestination(wallet: Wallet, jsonFilePath: string) {
  let jsonData;
  try {
    const fileContent = fs.readFileSync(jsonFilePath, 'utf-8');
    jsonData = JSON.parse(fileContent);
  } catch (error) {
    console.error("❌ Error reading JSON file:", error);
    return;
  }

  console.log("✅ Loaded existing JSON data.");

  // Backup previous values from JSON
  wallet.stateHashPrev = wallet.stateHashNew;
  wallet.blockHashPrev = wallet.blockHash;
  wallet.prevPath = wallet.path;

  jsonData.prev_state_hash = jsonData.state_hash;
  jsonData.prev_blockroot_path = jsonData.blockroot_path;
  jsonData.prev_blockroot = jsonData.blockroot;
  jsonData.prev_blockroot_length = jsonData.blockroot_length;
  jsonData.prev_proof = jsonData.proof;
  jsonData.prev_destinationsRoot = jsonData.destinationsRoot;

  // Generate and assign pkSaltHash
  wallet.pkSaltHash = randomField();

  const state = buildStateFromJson(jsonData);

  const messageHash = wallet.deriveDestination(wallet.pkSaltHash);

  wallet.logDestinations();


  // Store updated values in JSON
  jsonData.pkSaltHash = wallet.pkSaltHash.toString();
  jsonData.messageHash = messageHash.toString();
  jsonData.destinationsRoot = wallet.destinationsRoot.toString();
  jsonData.state_hash = wallet.stateHashNew.toString();

  //if (!Array.isArray(jsonData.hidden_addresses)) {
    jsonData.hidden_addresses = [];
  //}

  jsonData.hidden_addresses.push(wallet.destinationNew.toString());

  try {
    fs.writeFileSync(jsonFilePath, JSON.stringify(jsonData, null, 2));
    console.log("✅ Updated state stored in JSON file!");
  } catch (error) {
    console.error("❌ Error writing to JSON file:", error);
  }

  console.log("✅ Derivation initialized successfully.");
}

async function deriveDestination(jsonFilePath: string): Promise<Wallet | null> {
  let data;
  try {
    const fileContent = fs.readFileSync(jsonFilePath, 'utf-8');
    data = JSON.parse(fileContent);
  } catch (error) {
    console.error("❌ Error reading JSON file:", error);
    return null;
  }

  console.log("✅ JSON loaded. Reconstructing wallet...");


  // === Reconstruct Wallet from JSON ===
  const balance = new Field(data.Balance ?? 0);
  const wallet = new Wallet(balance);

  console.log("✅ Compiling...");

  const compiled = await transitionProgram.compile();
  console.log("✅ Compiled. Importing verification key...");

  const verificationKey = compiled.verificationKey;
  console.log("✅ Key imported. Creating class...");

  wallet.newStateProof = await MyProof.fromJSON(data.proof);
  console.log("✅ Proof imported. Verifying..");


  const isValid = await verify(wallet.newStateProof.toJSON(), verificationKey);

  console.log('wallet.newStateProof ok', isValid);

  console.log("DEBUG fields from JSON:");
  console.log("pkHash:", data.pkHash);
  console.log("addressdec:", data.addressdec);
  console.log("destinationsRoot:", data.destinationsRoot);
  console.log("hidden_input_txs:", data.hidden_input_txs);
  console.log("hidden_output_txs:", data.hidden_output_txs);
  //console.log("blockHash:", data.blockHash);

  wallet.pkHash = new Field(data.pkHash);
  wallet.address = new Field(data.addressdec);
  wallet.destinationsRoot = new Field(data.destinationsRoot);
  wallet.inTxsRootNew = new Field(data.hidden_input_txs);
  wallet.outTxsRoot = new Field(data.hidden_output_txs);
  wallet.blockHash = new Field(data.blockhashroot);
  wallet.stateHashNew = new Field(data.state_hash);

  // Backup previous values from JSON
  wallet.stateHashPrev = wallet.stateHashNew;
  wallet.blockHashPrev = wallet.blockHash;
  wallet.prevPath = wallet.path;

  data.prev_state_hash = data.state_hash;
  data.prev_blockroot_path = data.blockroot_path;
  data.prev_blockroot = data.blockroot;
  data.prev_blockroot_length = data.blockroot_length;
  data.prev_proof = data.proof;
  data.prev_destinationsRoot = data.destinationsRoot;

  wallet.logDestinations();

  for (let index = 0; index < data.hidden_addresses.length; index++) {
    // Take the next destination
    const destination = new Field(data.hidden_addresses[index]);
    wallet.Destinations.push(destination);

    // Put the new destination in the dest tree
    wallet.destinations.setLeaf(BigInt(index), destination);
  }

  wallet.logDestinations();

  // === Perform the destination derivation ===
  wallet.pkSaltHash = randomField();
  const messageHash = wallet.deriveDestination(wallet.pkSaltHash);
  wallet.logDestinations();

  // Store updated values in JSON
  data.destinationsRoot = wallet.destinationsRoot.toString();
  data.state_hash = wallet.stateHashNew.toString();
  data.hidden_addresses.push(wallet.destinationNew.toString());

  // === Update the JSON with new values ===
  data.pkSaltHash = wallet.pkSaltHash.toString();
  data.messageHash = messageHash.toString();

  try {
    fs.writeFileSync(jsonFilePath, JSON.stringify(data, null, 2));
    console.log("✅ Derivation complete and stored in JSON!");
  } catch (error) {
    console.error("❌ Error writing to JSON file:", error);
  }

  // === Return the updated Wallet ===
  return wallet;
}

async function moveToStealth(jsonFilePath: string): Promise<Wallet | null> {
  let data;
  try {
    const fileContent = fs.readFileSync(jsonFilePath, 'utf-8');
    data = JSON.parse(fileContent);
  } catch (error) {
    console.error("❌ Error reading JSON file:", error);
    return null;
  }

  console.log("✅ JSON loaded. Reconstructing wallet...");

  const amount = new Field(data.amount);

  // === Reconstruct Wallet from JSON ===
  const balance = new Field(data.Balance ?? 0);
  const wallet = new Wallet(balance);

  console.log("✅ Compiling...");

  const compiled = await transitionProgram.compile();
  console.log("✅ Compiled. Importing verification key...");

  const verificationKey = compiled.verificationKey;
  console.log("✅ Key imported. Creating class...");

  wallet.newStateProof = await MyProof.fromJSON(data.proof);
  console.log("✅ Proof imported. Verifying..");


  const isValid = await verify(wallet.newStateProof.toJSON(), verificationKey);

  console.log('wallet.newStateProof ok', isValid);

  console.log("DEBUG fields from JSON:");
  console.log("pkHash:", data.pkHash);
  console.log("addressdec:", data.addressdec);
  console.log("destinationsRoot:", data.destinationsRoot);
  console.log("hidden_input_txs:", data.hidden_input_txs);
  console.log("hidden_output_txs:", data.hidden_output_txs);
  //console.log("blockHash:", data.blockHash);

  wallet.pkHash = new Field(data.pkHash);
  wallet.address = new Field(data.addressdec);
  wallet.destinationsRoot = new Field(data.destinationsRoot);
  wallet.inTxsRootNew = new Field(data.hidden_input_txs);
  wallet.outTxsRoot = new Field(data.hidden_output_txs);
  wallet.blockHash = new Field(data.blockhashroot);
  wallet.stateHashNew = new Field(data.state_hash);
  wallet.balanceNew = new Field(data.Balance);
  wallet.destinationsRoot = new Field(data.destinationsRoot);

  // Backup previous values from JSON
  wallet.stateHashPrev = wallet.stateHashNew;
  wallet.blockHashPrev = wallet.blockHash;
  wallet.prevPath = wallet.path;
  wallet.balance = wallet.balanceNew;


  data.prev_state_hash = data.state_hash;
  data.prev_blockroot_path = data.blockroot_path;
  data.prev_blockroot = data.blockroot;
  data.prev_blockroot_length = data.blockroot_length;
  data.prev_proof = data.proof;
  data.prev_destinationsRoot = data.destinationsRoot;


  const messageHash = await wallet.increaseStealthFunds(amount);

  // Store updated values in JSON
  data.destinationsRoot = wallet.destinationsRoot.toString();
  data.state_hash = wallet.stateHashNew.toString();
  //data.hidden_addresses.push(wallet.destinationNew.toString());

  data.Balance = wallet.balanceNew.toString();
  console.log("new balance:", data.Balance);
  console.log("amount:", amount.toString());


  // === Update the JSON with new values ===
  //data.pkSaltHash = wallet.pkSaltHash.toString();
  data.messageHash = messageHash.toString();

  try {
    fs.writeFileSync(jsonFilePath, JSON.stringify(data, null, 2));
    console.log("✅ Funding complete and stored in JSON!");
  } catch (error) {
    console.error("❌ Error writing to JSON file:", error);
  }

  // === Return the updated Wallet ===
  return wallet;
}



export async function proveDeriveDestination(wallet: Wallet, jsonFilePath: string) {
  const messageHash = treeHasher.createMerkleTree([
    wallet.address,
    wallet.stateHashNew
  ]);
  console.log(`proveDeriveDestination wallet.stateHashNew: ${wallet.stateHashNew.toString()}`);
  console.log(`proveDeriveDestination message hash: ${messageHash.toString()}`);

  let data;
  try {
    const fileContent = fs.readFileSync(jsonFilePath, 'utf-8');
    data = JSON.parse(fileContent);
  } catch (error) {
    console.error("❌ Error reading JSON file:", error);
    return null;
  }

  const paths = constructMerklePathsFromJson(jsonFilePath);
  if (!paths) {
    console.error("Failed to process Merkle paths.");
    return wallet;
  }

  let mergedMerklePath = mergeMerklePaths(paths);
  mergedMerklePath = extendMerklePath(mergedMerklePath, paths.blockhashroot);
  wallet.blockHash = new Field(paths.blockhashroot);

  verifyMerklePath(messageHash, paths.blockhashroot, mergedMerklePath);
  console.log("✅ Valid Merged Merkle Path");

  const path = constructMerklePathFromJson(jsonFilePath);
  if (!path) {
    console.error("Failed to process Merkle path.");
    return wallet;
  }

  let prevMerklePath = [...path.blockhashrootPath, path.blockhashroot, path.blockhashroot];
  prevMerklePath = extendMerklePath(prevMerklePath, path.blockhashroot);

  verifyMerklePath(wallet.blockHashPrev, path.blockhashroot, prevMerklePath);
  console.log("✅ Valid Prev Merkle Path");

  wallet.path = new fieldArray({ array: mergedMerklePath });
  wallet.prevPath = new fieldArray({ array: prevMerklePath });;

  const myPublicOutputs = new MyPublicOutputs({
    Leaf: wallet.stateHashPrev,
    Root: wallet.blockHashPrev
  });

  const compiled = await transitionProgram.compile();
  const verificationKey = compiled.verificationKey;

  const result = await wallet.proveStateAfterDestinationDerivation(
    wallet.pkSaltHash,
    wallet.prevPath,
    wallet.path,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);

  if (isValid) {
    fs.writeFileSync(jsonFilePath, JSON.stringify({ ...data, proof: result.toJSON() }, null, 2));
    console.log("✅ Proof stored in JSON file");
  }

}

export async function proveBurnToStealth(wallet: Wallet, jsonFilePath: string) {
  const messageHash = treeHasher.createMerkleTree([wallet.address, Field(0), wallet.balanceNew.sub(wallet.balance), wallet.stateHashNew]);

  console.log(`proveBurnToStealth wallet.stateHashNew: ${wallet.stateHashNew.toString()}`);
  console.log(`proveBurnToStealth message hash: ${messageHash.toString()}`);

  let data;
  try {
    const fileContent = fs.readFileSync(jsonFilePath, 'utf-8');
    data = JSON.parse(fileContent);
  } catch (error) {
    console.error("❌ Error reading JSON file:", error);
    return null;
  }

  const paths = constructMerklePathsFromJson(jsonFilePath);
  if (!paths) {
    console.error("Failed to process Merkle paths.");
    return wallet;
  }

  let mergedMerklePath = mergeMerklePaths(paths);
  mergedMerklePath = extendMerklePath(mergedMerklePath, paths.blockhashroot);
  wallet.blockHash = new Field(paths.blockhashroot);

  verifyMerklePath(messageHash, paths.blockhashroot, mergedMerklePath);
  console.log("✅ Valid Merged Merkle Path");

  const path = constructMerklePathFromJson(jsonFilePath);
  if (!path) {
    console.error("Failed to process Merkle path.");
    return wallet;
  }

  let prevMerklePath = [...path.blockhashrootPath, path.blockhashroot, path.blockhashroot];
  prevMerklePath = extendMerklePath(prevMerklePath, path.blockhashroot);

  verifyMerklePath(wallet.blockHashPrev, path.blockhashroot, prevMerklePath);
  console.log("✅ Valid Prev Merkle Path");

  wallet.path = new fieldArray({ array: mergedMerklePath });
  wallet.prevPath = new fieldArray({ array: prevMerklePath });;

  const myPublicOutputs = new MyPublicOutputs({
    Leaf: wallet.stateHashPrev,
    Root: wallet.blockHashPrev
  });

  const compiled = await transitionProgram.compile();
  const verificationKey = compiled.verificationKey;

  const result = await wallet.proveFundsBurning(
    wallet.balanceNew.sub(wallet.balance),
    wallet.prevPath,
    wallet.path,
    myPublicOutputs
  );

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);

  if (isValid) {
    fs.writeFileSync(jsonFilePath, JSON.stringify({ ...data, proof: result.toJSON() }, null, 2));
    console.log("✅ Proof stored in JSON file");
  }

}


async function main() {
  const args = process.argv.slice(2);
  if (args.length < 1) {
    await interactive();
    process.exit(1);
  }

  const functionToCall = args[0];
  const functionArgs = args.slice(1);

  try {
    switch (functionToCall) {
      case 'init':
        await callPythonScript('initialize_wallet.py');
        break;
      case 'keys':
        await callPythonScript('show_keys.py');
        break;
      case 'balance':
        await callPythonScript('show_balance.py');
        break;
      case 'delete':
        await callPythonScript('delete_wallet.py');
        break;
      case 'create':
        await callPythonScript('sponsor_create_account.py');
        break;
      case 'transfer':
        await callPythonScript('transfer.py');
        break;
      case 'stake':
        await callPythonScript('stake.py');
        break;
      case 'unstake':
        await callPythonScript('unstake.py');
        break;
      case 'update':
        await callPythonScript('update_state_hash.py');
        break;
      case 'send_stealth':
        await callPythonScript('send_stealth.py');
        break;
      case 'receive_stealth':
        await callPythonScript('receive_stealth.py');
        break;
      case 'show_stealth_addresses':
        await callPythonScript('show_stealth_addresses.py');
        break;
      case 'show_stealth_balance':
        await callPythonScript('show_stealth_balance.py');
        break;
      case 'transfer_to_stealth':
        await callPythonScript('transfer_with_burn_to_stealth.py');
        break;
      case 'run_tests':
        await runAllTests();
        break;
      case 'initialize_wallet_sponsor':
        await callPythonScript('initialize_wallet_sponsor.py');
        break;
      case 'initialize_wallet_client':
        await callPythonScript('initialize_wallet_client.py');
        break;
      case 'help':
        console.log("Available commands: init, keys, balance, delete, create, transfer, stake, unstake, update, send_stealth, receive_stealth, show_stealth_addresses, show_stealth_balance, transfer_to_stealth, run_tests, initialize_wallet_sponsor, initialize_wallet_client");
        break;
      default:
        await interactive();
    }
  } catch (error) {
    console.error('Error:', error);
  }
}

await main();

process.exit(1);
