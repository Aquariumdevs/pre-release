#!/bin/bash

# Ensure the script stops on the first error
set -e

# Build the library
cargo build --release

# tranfer the lib
cp target/release/libsimple_example.so ../node/

