#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str
from show_balance import show_balance
from calculate_state_hash import calculate_state_hash
from construct_proofs import construct_proofs

def prepare_transfer_with_burn_to_stealth():
    state = load_wallet_state()
    if not all(key in state for key in ['secret', 'address', 'counter', 'state_hash']):
        print("Wallet is not properly initialized or missing vital information.")
        return

    # This is the burn address; funds sent here are considered 'burnt'
    burn_address = '00000000'

    amount_input = input("Enter the amount to transfer to stealth: ").strip()
    if not amount_input.isdigit() or int(amount_input) <= 0:
        print("Invalid amount. Please enter a positive integer.")
        return

    state['amount'] = int(amount_input)
    if state['balance'] < state['amount']:
        print("Insufficient balance to perform the operation.")
        return

    save_wallet_state(state)


if __name__ == "__main__":
    prepare_transfer_with_burn_to_stealth()
