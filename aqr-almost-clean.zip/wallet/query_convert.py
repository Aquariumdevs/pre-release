#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str




# Function to retrieve paths
def query_convert():
    state = load_wallet_state()

    state_hash = state.get('state_hash')
    # Convert decimal string to Python int

    big_int_from_dec = int(state_hash, 10)

    #state["state_hash_hex"] = str(hex(big_int_from_dec)[2:])
    #save_wallet_state(state)


    try:
        query_output = call_go_wallet("query", [state_hash])
        _bytes = query_output.strip('[]').split()

        print(len(_bytes))

        if len(_bytes) > 63:  # Ensure valid response length

            new_state_hash = "".join(chr(int(byte)) for byte in _bytes[:64])


            # Initialize missing values in state if not present
            state['state_hash_hex'] = new_state_hash


            # Save the updated state
            save_wallet_state(state)
            print(state)

            print("Convertion completed.")


        else:
            print("Failed to retrieve a valid convertion. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query information: {e}")


if __name__ == "__main__":
    query_convert()

