#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str


# Function to build request for paths
def get_request_for(public_key):
    request_key = public_key + "00"
    return request_key

# Function to retrieve paths
def query_pk_decimal():
    state = load_wallet_state()

    try:
        query_output = call_go_wallet("query", [get_request_for(state['public_key'])])
        _bytes = query_output.strip('[]').split()

        print(len(_bytes))

        if len(_bytes) > 77:  # Ensure valid response length

            # Convert the first 78 ASCII bytes to a string
            decaddress = "".join(chr(int(byte)) for byte in _bytes[:78])
            print(f"Retrieved dec pkhash: {decpkhash}")


            # Initialize missing values in state if not present
            state['pkhash'] = decpkhash


            # Save the updated state
            save_wallet_state(state)


        else:
            print("Failed to retrieve a valid dec. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query path information: {e}")


if __name__ == "__main__":
    query_pk_decimal()

