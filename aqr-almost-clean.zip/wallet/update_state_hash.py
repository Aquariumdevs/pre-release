#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64
import re

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str
from show_balance import show_balance


def extract_height(response_body: str):
    try:
        # Extract JSON part from the response using regex
        match = re.search(r'\{.*\}', response_body, re.DOTALL)
        if not match:
            return None

        json_data = json.loads(match.group())

        check = int(json_data["result"]["check_tx"]["code"])
        deliver = int(json_data["result"]["deliver_tx"]["code"])
        if check != 0 or deliver != 0:
            return 0

        height = int(json_data["result"]["height"])
        return height
    except (KeyError, ValueError, TypeError, json.JSONDecodeError):
        return None

def extract_success(response_body: str):
    try:
        # Extract JSON part from the response using regex
        match = re.search(r'\{.*\}', response_body, re.DOTALL)
        if not match:
            return None

        json_data = json.loads(match.group())
        height = int(json_data["result"]["height"])
        return height
    except (KeyError, ValueError, TypeError, json.JSONDecodeError):
        return None

def update_state_hash():
    print("updating...")
    state = load_wallet_state()
    if not all(key in state for key in ['secret', 'address', 'counter', 'state_hash']):
        print("Wallet is not properly initialized or missing vital information.")
        return

    secret = state['secret']
    state_hash = state['state_hash']  # Assume this is calculated elsewhere

    big_int_from_dec = int(state_hash, 10)

    state_hash_hex = str(hex(big_int_from_dec)[2:])
    padded_hex = state_hash_hex.zfill(64)
    print(padded_hex)
    print([state_hash])
    padded_dec = state_hash.zfill(78)
    print(padded_dec)
    padded_dec_hex = padded_dec.encode('utf-8').hex()

    try:
        query_output = call_go_wallet("query", [padded_dec_hex])
        _bytes = query_output.strip('[]').split()

        print(_bytes)

        if len(_bytes) > 63:  # Ensure valid response length

            new_state_hash = "".join(chr(int(byte)) for byte in _bytes[:64])


            # Initialize missing values in state if not present
            state['state_hash_hex'] = new_state_hash


            # Save the updated state
            save_wallet_state(state)

            print("Convertion completed.")


        else:
            print("Failed to retrieve a valid convertion. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query information: {e}")

    counter_hex = int_to_hex_str(int(state['counter']))
    source = int_to_hex_str(int(state['address']))

    show_balance()
    state = load_wallet_state()
    prev_balance = state['balance']

    try:
        update_output = call_go_wallet("UpdateTx", [secret, source, new_state_hash, counter_hex])
        print("update_output:")
        print(update_output)
        print("<<update_output")
        height_value = extract_height(update_output)
        print("height_value:")


        show_balance()
        state = load_wallet_state()
        state.setdefault('height_value', height_value)
        state['prev_height_value'] = state['height_value']
        state['height_value'] = height_value + 1

        print(state['height_value'])

        if prev_balance != state['balance']:
            print("Update successful!")
            state['counter'] += 1  # Increment the transaction counter
            save_wallet_state(state)
        else:
            print("Unsuccessful operation!")
    except Exception as e:
        print(f"Failed to update state hash: {e}")

if __name__ == "__main__":
    update_state_hash()

