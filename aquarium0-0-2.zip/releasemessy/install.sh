#!/bin/bash

# Check if Git is installed
if ! command -v git &> /dev/null
then
    echo "Git is not installed or not found in PATH. Please install Git and try again."
    exit 1
fi

# Navigate to the rustlib directory and run the start script
cd rustlib
./start.sh
cd ..

# Ensure the base directory for Go apps exists
mkdir -p $HOME/go/apps

# Copy the 'node' directory into its own subdirectory in 'apps'
# Ensure the destination directory is clean before copying
if [ -d "$HOME/go/apps/node" ]; then
    echo "Removing existing 'node' directory at $HOME/go/apps/node"
    rm -rf "$HOME/go/apps/node"
fi
cp -r node $HOME/go/apps/node
echo "'node' directory copied successfully."

# Copy the 'wallet' directory into its own subdirectory in 'apps'
# Ensure the destination directory is clean before copying
if [ -d "$HOME/go/apps/wallet" ]; then
    echo "Removing existing 'wallet' directory at $HOME/go/apps/wallet"
    rm -rf "$HOME/go/apps/wallet"
fi
cp -r wallet $HOME/go/apps/wallet
echo "'wallet' directory copied successfully."

# Compile the Go application
./go_compile.sh

# Navigate to the o1js directory and run the start script
cd o1js
./start.sh
cd ..


# Copy the wallet executable and Python files to the o1js/zkwallet/build/src/ directory
cp $HOME/go/apps/wallet/wallet o1js/zkwallet/build/src/
echo "Wallet executable copied successfully."

cp $HOME/go/apps/wallet/*.py o1js/zkwallet/build/src/
cp $HOME/go/apps/wallet/*.json o1js/zkwallet/build/src/
echo "Python files copied successfully."
