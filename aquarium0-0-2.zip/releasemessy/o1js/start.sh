#!/bin/bash

# Define project name and source folder path
PROJECT_NAME="zkwallet"

# Ensure npm installs global packages in user directory to avoid permission issues
# You can skip this if you have already configured npm to use a different directory
# mkdir -p $HOME/.npm-global
# npm config set prefix "$HOME/.npm-global"
# export PATH="$HOME/.npm-global/bin:$PATH"

# Install or update the zkApp CLI

# Check if the zkApp CLI was installed correctly
if ! command -v zk &> /dev/null
then
    sudo npm install -g zkapp-cli  # Use sudo to avoid EACCES error
fi

# Check if the zkApp CLI was installed correctly
if ! command -v zk &> /dev/null
then
    echo "zkApp CLI could not be found or installed. Exiting."
    exit 1
fi

# Create a new zkApp project
zk project $PROJECT_NAME

# Change directory to the new project
cd $PROJECT_NAME
cd src
# Remove the generated src folder
rm -f *

# Move existing src folder to the project directory
cp ../../src/* .

cd ..

# Build the project
npm install o1js@0.17.0
npm run build
