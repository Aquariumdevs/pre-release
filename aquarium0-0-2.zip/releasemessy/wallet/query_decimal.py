#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str


# Function to build request for paths
def get_request_for_addr(address):
    request_key = address + "00"
    return request_key

# Function to retrieve paths
def query_decimal():
    state = load_wallet_state()

    address = state.get('address')
    if not address:
        print("Local Address Index: Not Available - Attempting to retrieve from blockchain...")
        if 'bls_public_key' in state:
            try:
                output = call_go_wallet("query", [state['bls_public_key']])
                address_bytes = output.strip('[]').split()
                if len(address_bytes) == 4:
                    # Convert from list of byte values to hex string
                    address = ''.join(format(int(b), '02x') for b in address_bytes)
                    # Update state with new address
                    state['address'] = address
                    save_wallet_state(state)
                    print(f"Retrieved 4-byte Address Index: {address}")
                else:
                    print("The wallet is not yet on-chain or there's a connection issue.")
                    return
            except Exception as e:
                print(f"Failed to query on-chain information: {e}")
                return
        else:
            print("BLS Public Key not found. Please initialize the wallet.")
            return

    # Query for paths using the 4-byte address
    try:
        query_output = call_go_wallet("query", [get_request_for_addr(address)])
        _bytes = query_output.strip('[]').split()

        print(len(_bytes))

        if len(_bytes) > 155:  # Ensure valid response length

            # Convert the first 78 ASCII bytes to a string
            decaddress = "".join(chr(int(byte)) for byte in _bytes[:78])
            decpkhash = "".join(chr(int(byte)) for byte in _bytes[78:156])
            print(f"Retrieved dec Address: {decaddress}")
            print(f"Retrieved dec pkhash: {decpkhash}")


            # Initialize missing values in state if not present
            state['addressdec'] = decaddress
            state['pkHash'] = decpkhash


            # Save the updated state
            save_wallet_state(state)



        else:
            print("Failed to retrieve a valid dec. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query path information: {e}")


if __name__ == "__main__":
    query_decimal()

