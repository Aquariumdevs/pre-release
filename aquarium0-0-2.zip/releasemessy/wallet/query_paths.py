#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str


# Function to build request for paths
def get_request_for_paths(state, address):
    counter = state.get("counter", 0) - 1
    counter_big_endian = struct.pack('>I', counter)
    request_key = address + counter_big_endian.hex()
    return request_key

# Function to retrieve paths
def query_paths():
    state = load_wallet_state()

    address = state.get('address')
    if not address:
        print("Local Address Index: Not Available - Attempting to retrieve from blockchain...")
        if 'bls_public_key' in state:
            try:
                output = call_go_wallet("query", [state['bls_public_key']])
                address_bytes = output.strip('[]').split()
                if len(address_bytes) == 4:
                    # Convert from list of byte values to hex string
                    address = ''.join(format(int(b), '02x') for b in address_bytes)
                    # Update state with new address
                    state['address'] = address
                    save_wallet_state(state)
                    print(f"Retrieved 4-byte Address Index: {address}")
                else:
                    print("The wallet is not yet on-chain or there's a connection issue.")
                    return
            except Exception as e:
                print(f"Failed to query on-chain information: {e}")
                return
        else:
            print("BLS Public Key not found. Please initialize the wallet.")
            return

    # Query for paths using the 4-byte address
    try:
        query_output = call_go_wallet("query", [get_request_for_paths(state, address)])
        path_bytes = query_output.strip('[]').split()

        print(len(path_bytes))

        if len(path_bytes) > 145:  # Ensure valid response length
            index = 0

            # Extract key (8 bytes)
            key1 = path_bytes[index:index + 8]
            index += 8

            # Extract blockroot (32 bytes)
            # blockroot = path_bytes[index:index + 32]
            index += 32

            # Extract blockroot (78 bytes)
            blockroot_path_bytes = path_bytes[index:index + 78]
            index += 78

            # Convert the first 78 ASCII bytes to a string
            blockroot = "".join(chr(int(byte)) for byte in blockroot_path_bytes[:78])

            # Extract blockroot path length (1 byte)
            blockroot_length = int(path_bytes[index], 10)
            index += 1

            # Extract blockroot path hashes (N * 78 bytes)
            blockroot_path_bytes = path_bytes[index:index + (blockroot_length * 78)]
            index += (blockroot_length * 78)

            # Convert ASCII bytes to strings
            blockroot_path = [
                "".join(chr(int(byte)) for byte in blockroot_path_bytes[i:i+78])
                for i in range(0, len(blockroot_path_bytes), 78)
            ]

            # Extract key (8 bytes)
            key2 = path_bytes[index:index + 8]
            index += 8

            # Extract blockhashroot (32 bytes)
            # blockhashroot = path_bytes[index:index + 32]
            index += 32

            # Extract blockhashroot (78 bytes)
            blockhashroot_path_bytes = path_bytes[index:index + 78]
            index += 78

            # Convert the first 78 ASCII bytes to a string
            blockhashroot = "".join(chr(int(byte)) for byte in blockhashroot_path_bytes[:78])


            # Extract blockhashroot path length (1 byte)
            blockhashroot_length = int(path_bytes[index], 10)
            index += 1

            # Extract blockhashroot path hashes (M * 32 bytes)
            blockhashroot_path_bytes = path_bytes[index:index + (blockhashroot_length * 78)]
            index += (blockhashroot_length * 78)


            # Convert ASCII bytes to strings
            blockhashroot_path = [
                "".join(chr(int(byte)) for byte in blockhashroot_path_bytes[i:i+78])
                for i in range(0, len(blockhashroot_path_bytes), 78)
            ]

            print(f"path_bytes: {path_bytes}")
            print(f"index: {index}")
            print(f"Key1: {key1}")
            print(f"Key2: {key2}")
            print(f"Blockroot: {blockroot}")
            print(f"Blockhashroot: {blockhashroot}")
            print(f"Blockroot Path Length: {blockroot_length}")
            print(f"Blockroot Path: {blockroot_path}")
            print(f"Blockhashroot Path Length: {blockhashroot_length}")
            print(f"Blockhashroot Path: {blockhashroot_path}")

            # Validate extracted lengths
            if index > len(path_bytes):
                raise ValueError("Path response is incomplete or incorrectly formatted.")

            # Initialize missing values in state if not present
            state['path_query_key1'] = key1
            state['path_query_key2'] = key2
            state['blockroot'] = blockroot
            state['blockhashroot'] = blockhashroot
            state['blockroot_length'] = blockroot_length
            state['blockroot_path'] = blockroot_path
            state['blockhashroot_length'] = blockhashroot_length
            state['blockhashroot_path'] = blockhashroot_path

            # Save the updated state
            save_wallet_state(state)



        else:
            print("Failed to retrieve a valid path. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query path information: {e}")


if __name__ == "__main__":
    query_paths()

