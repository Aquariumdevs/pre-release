#!/usr/bin/env python3
import subprocess
import json
import sys
import os
import hashlib
import requests
import math
import struct
import base64
import re

from common import load_wallet_state, save_wallet_state, call_go_wallet, get_block_hash, int_to_hex_str
from show_balance import show_balance
from calculate_state_hash import calculate_state_hash
from construct_proofs import construct_proofs


def extract_height(response_body: str):
    try:
        # Extract JSON part from the response using regex
        match = re.search(r'\{.*\}', response_body, re.DOTALL)
        if not match:
            return None

        json_data = json.loads(match.group())

        check = int(json_data["result"]["check_tx"]["code"])
        deliver = int(json_data["result"]["deliver_tx"]["code"])
        if check != 0 or deliver != 0:
            return 0

        height = int(json_data["result"]["height"])
        return height
    except (KeyError, ValueError, TypeError, json.JSONDecodeError):
        return None

def extract_success(response_body: str):
    try:
        # Extract JSON part from the response using regex
        match = re.search(r'\{.*\}', response_body, re.DOTALL)
        if not match:
            return None

        json_data = json.loads(match.group())
        height = int(json_data["result"]["height"])
        return height
    except (KeyError, ValueError, TypeError, json.JSONDecodeError):
        return None

def transfer_with_burn_to_stealth():
    print("burning...")
    state = load_wallet_state()
    if not all(key in state for key in ['secret', 'address', 'counter', 'state_hash']):
        print("Wallet is not properly initialized or missing vital information.")
        return

    # This is the burn address; funds sent here are considered 'burnt'
    burn_address_code = '00000000'
    burn_address = int_to_hex_str(int(burn_address_code))

    secret = state['secret']
    state_hash = state['state_hash']  # Assume this is calculated elsewhere

    big_int_from_dec = int(state_hash, 10)

    state_hash_hex = str(hex(big_int_from_dec)[2:])
    padded_hex = state_hash_hex.zfill(64)
    print(padded_hex)
    print([state_hash])
    padded_dec = state_hash.zfill(78)
    print(padded_dec)
    padded_dec_hex = padded_dec.encode('utf-8').hex()


    try:
        query_output = call_go_wallet("query", [padded_dec_hex])
        _bytes = query_output.strip('[]').split()

        print(_bytes)

        if len(_bytes) > 63:  # Ensure valid response length

            new_state_hash = "".join(chr(int(byte)) for byte in _bytes[:64])


            # Initialize missing values in state if not present
            state['state_hash_hex'] = new_state_hash


            # Save the updated state
            save_wallet_state(state)

            print("Convertion completed.")


        else:
            print("Failed to retrieve a valid convertion. The response format is incorrect.")
    except Exception as e:
        print(f"Failed to query information: {e}")

    #the same for amount
    amount = state['amount']
    amount_hex = int_to_hex_str(int(amount))

    counter_hex = int_to_hex_str(int(state['counter']))
    source = int_to_hex_str(int(state['address']))

    show_balance()
    state = load_wallet_state()
    prev_balance = state['balance']

    try:
        update_output = call_go_wallet("transferWithUpdateTx", [secret, source, burn_address, amount_hex, new_state_hash, counter_hex])
        print("update_output:")
        print(update_output)
        print("<<update_output")
        height_value = extract_height(update_output)
        print("height_value:")


        show_balance()
        state = load_wallet_state()
        state.setdefault('height_value', height_value)
        state['prev_height_value'] = state['height_value']
        state['height_value'] = height_value + 1

        print(state['height_value'])

        if prev_balance != state['balance']:
            print("Update successful!")
            state['counter'] += 1  # Increment the transaction counter
            save_wallet_state(state)
        else:
            print("Unsuccessful operation!")
    except Exception as e:
        print(f"Failed to update state hash and burn: {e}")


"""
    state = load_wallet_state()
    if not all(key in state for key in ['secret', 'address', 'counter', 'state_hash']):
        print("Wallet is not properly initialized or missing vital information.")
        return

    state_backup = state

    secret = state['secret']
    source = int_to_hex_str(int(state['address']))

    # This is the burn address; funds sent here are considered 'burnt'
    burn_address = '00000000'

    amount = state['amount']

    amount_hex = int_to_hex_str(amount)
    counter_hex = int_to_hex_str(int(state['counter']))
    state_hash = state['state_hash']  # The current state hash before updating

    show_balance()
    state = load_wallet_state()  # Reload state after the operation

    try:
        show_balance()
        state = load_wallet_state()
        prev_balance = state['balance']
        # Sending the transparent funds to be burnt in exchange for stealth funds
        transfer_output = call_go_wallet("transferWithUpdateTx", [secret, source, burn_address, amount_hex, new_state_hash, counter_hex])

        show_balance()
        state = load_wallet_state()  # Reload state after the operation

        if prev_balance == state['balance']:  # Checking if balance was correctly updated
            print("Failed to burn transparent funds. Transaction unsuccessful.")
            save_wallet_state(state_backup)
        else:
            print("Transparent funds successfully burnt. Updating stealth balance.")
            state['counter'] += 1  # Increment the transaction counter

            # Construct a new proof for the updated state
            #new_proofs = construct_proofs(state, new_utxo)

            save_wallet_state(state)

            print(f"Stealth balance updated successfully. New state hash: {new_state_hash}")
            print(f"New proofs constructed for the updated state: {new_proofs}")
    except Exception as e:
        print(f"Failed to update state hash: {e}")
        save_wallet_state(state_backup)
"""

if __name__ == "__main__":
    transfer_with_burn_to_stealth()
