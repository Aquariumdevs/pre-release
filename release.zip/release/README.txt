# AQUARIUM

## Overview

This is a demo version to show the world that this technology is possible. It is buggy, it has memory leaks, and it is not yet secure.

## Prerequisites

Before running the system, ensure that the following dependencies are installed on your Linux system:

- **Node.js**
- **Go**
- **Rust**
- **Python** (with virtual environment support)

If these dependencies are not already installed, you can use the `preinstall.sh` script to automatically install and configure them.


## Installation and Setup

### Step 1: Install Dependencies (Optional)

Run the `preinstall.sh` script to install and configure the necessary dependencies:

./preinstall.sh

After running the script, apply the changes to your environment by sourcing your profile:

source ~/.profile

If you're using a Python virtual environment, activate it with:

source $VENV_DIR/bin/activate


### Step 2: Install the Project

Run the install script to set up the project:

./install

On creating zkproject, select none

This will prepare all necessary components for the project to run, including installing Node.js packages, compiling Go and Rust code, and installing Python dependencies if required.
Running the System

### To execute a full test of the system, run:

./run.sh

What the Test Does

    Starts the required services and applications in the background.
    Exposes a simple wallet interface to demonstrate its capabilities
    After the test completes, the system automatically resets to its original state, restoring files like wallet_state.json.


### Troubleshooting

If you encounter any issues:

    Ensure all dependencies are installed.
    Verify your environment is configured correctly (e.g., PATH variables, Python virtual environment).
    Ensure you're running the run.sh script from the correct directory.

### License

This project is licensed under the GNU General Public License v3.0. See the LICENSE file for details.
