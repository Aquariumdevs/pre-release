
cd $HOME/go/apps

cd node
./start.sh
cd ..

cd wallet
./start.sh
cd ..

