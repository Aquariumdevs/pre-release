#!/bin/bash

cd rustlib
./start.sh
cd ..

cp -r node $HOME/go/apps
cp -r wallet $HOME/go/apps

./go_compile.sh

cd o1js
./start.sh
cd ..

cp $HOME/go/apps/wallet/wallet o1js/zkwallet/build/src/
cp $HOME/go/apps/wallet/*.py o1js/zkwallet/build/src/


