#/bin/bash
CGO_CFLAGS="-O -D__BLST_PORTABLE__"
CGO_CFLAGS_ALLOW="-O -D__BLST_PORTABLE__"
export CGO_CFLAGS
export CGO_CFLAGS_ALLOW
export LD_LIBRARY_PATH=.
rm -rf ~/.tendermint/*
rm -rf contractdb*
rm -rf accdb*
rm -rf condb
rm -rf badg*
rm -rf data
#cp -r /home/userland/tm/* /home/userland/.tendermint/
cp -r init/* ~/.tendermint/
#./tendermint init
#./kvstore init
./zknode -config ../../../.tendermint/config/config.toml
