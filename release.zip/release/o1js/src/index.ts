import { transitionProgram } from './transition.js';

export { transitionProgram };
