import { fieldArray, Wallet, transitionProgram, MyPublicOutputs, hashInputs, MerkleWitness4, FastTree } from './transition.js';
import { Field, Gadgets, MerkleMap, MerkleMapWitness, verify, Poseidon, VerificationKey, MerkleTree } from 'o1js';
import { spawn } from 'child_process';
import * as readline from 'readline';
// Helper function to generate a random Field value
function randomField(): Field {
  return new Field(Math.floor(Math.random() * Number.MAX_SAFE_INTEGER));
}

// Function to simulate a Merkle path
function simulateMerklePaths(leaf1: Field, leaf2: Field, depth: number = 128): fieldArray {
  let path = [leaf1];
  const right = leaf2;

    for (let i = 0; i < 128; i += 2) {

      const left = path[i];
      let right = Field("60"); // Simulating a paired node
      if(i == 0) {
        right = leaf2;
      }
      path.push(right);
      const hash = treeHasher.createMerkleTree([left, right]);
      path.push(hash);
    }
 
  // The last hash is the root
  return new fieldArray({ array: path });
}

function simulateMerklePath(leaf: Field, depth: number = 128): fieldArray {
  let path = [leaf];
  //let currentLevel = [leaf];

  //while (currentLevel.length > 1) {
    //let nextLevel = [];
    for (let i = 0; i < 128; i += 2) {

      const left = path[i];
      const right = new Field("60");  // Simulating a paired node
      path.push(right);
      const hash = treeHasher.createMerkleTree([left, right]);
      path.push(hash);
    }

  // The last hash is the root
  return new fieldArray({ array: path });
}

// Random initialization tester function
async function testRandomInitialization() {
  // Create a random balance and initial block hash
  const balance = Field(0);
  
  // Initialize the wallet with random balance
  const wallet = new Wallet(balance);
  wallet.balance = Field(0);

  // Assign random values to other necessary fields
  const blsPublicKeyPart1 = randomField();
  const blsPublicKeyPart2 = randomField();

  wallet.pkHash = randomField(); 
  wallet.address = randomField(); 

  const stateHash = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balance, wallet.inTxsRootNew, wallet.outTxsRoot]);
  const messageHash = treeHasher.createMerkleTree([wallet.address, wallet.pkHash, /*blsPublicKeyPart1, blsPublicKeyPart2,*/ stateHash]);
  console.log(`message hash: ${messageHash.toString()}`);

  // Prepare Merkle paths
  const msgInclusionPath = simulateMerklePath(messageHash);

  const initialBlockHash = msgInclusionPath.array[msgInclusionPath.array.length - 1];
  wallet.blockHash = initialBlockHash; // Set the initial block hash as the leaf of the Merkle path

  const myPublicOutputs = new MyPublicOutputs({
    Leaf: initialBlockHash, // The initial block hash is the leaf
    Root: msgInclusionPath.array[msgInclusionPath.array.length - 1] // The last element is the root
  });

  // Call the initialize state and prove method
    const result = await wallet.initializeStateAndProve(
      blsPublicKeyPart1,
      blsPublicKeyPart2,
      msgInclusionPath,
      //inclusionPath,
      myPublicOutputs
    );
    //console.log('Initialization test result:', result);

    const isValid = await verify(result.toJSON(), verificationKey);
    console.log('ok', isValid);

    return wallet;
}

async function testDeriveDestination(wallet: Wallet) {
  
  const stateHashPrev = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balanceNew, wallet.inTxsRootNew, wallet.outTxsRoot]);
  
  const pkSaltHash = randomField();
  const messageHash = wallet.deriveDestination( pkSaltHash );

  const inclusionPath = wallet.path;
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // The initial block hash is the leaf
    Root: inclusionPath.array[inclusionPath.array.length - 1] // The last element is the root
  });

  const msgInclusionPath = simulateMerklePaths(messageHash, myPublicOutputs.Root);
  
  wallet.blockHash = msgInclusionPath.array[msgInclusionPath.array.length - 1] // The last element is the root

  // Call the function that wraps the zk-program call
  const result = await wallet.proveStateAfterDestinationDerivation(
    pkSaltHash,
    msgInclusionPath,//prev
    msgInclusionPath,
    myPublicOutputs
  );

  //console.log('Destination derivation proof result:', result);

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);
}

async function testBurnToStealth(wallet: Wallet) {
  // Store a snapshot of the current state before making changes

  
  const stateHashPrev = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balanceNew, wallet.inTxsRootNew, wallet.outTxsRoot]);
  
  const amount = Field("10");
  const messageHash = wallet.increaseStealthFunds( amount );

  // Prepare Merkle paths

  const inclusionPath = wallet.path;
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // The initial block hash is the leaf
    Root: inclusionPath.array[inclusionPath.array.length - 1] // The last element is the root
  });

  const msgInclusionPath = simulateMerklePaths(messageHash, myPublicOutputs.Root);
  
  wallet.blockHash = msgInclusionPath.array[msgInclusionPath.array.length - 1] // The last element is the root

  // Call the function that wraps the zk-program call
  const result = await wallet.proveFundsBurning(
    amount,
    msgInclusionPath,//prev
    msgInclusionPath,
    myPublicOutputs
  );

  //console.log('Destination derivation proof result:', result);/**/

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);
}

async function testSendTx(wallet: Wallet) {
  // Store a snapshot of the current state before making changes

  
  const stateHashPrev = treeHasher.createMerkleTree([wallet.pkHash, wallet.address, wallet.destinationsRoot, wallet.balanceNew, wallet.inTxsRootNew, wallet.outTxsRoot]);
  
  const destination = wallet.Destinations[0];
  const amount = Field("5");
  const salt = wallet.destinationsRoot; //this should be changed

  const messageHash = wallet.constructNewTx(destination, amount, salt);

  // Prepare Merkle paths

  const inclusionPath = wallet.path;
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // The initial block hash is the leaf
    Root: inclusionPath.array[inclusionPath.array.length - 1] // The last element is the root
  });

  const msgInclusionPath = simulateMerklePaths(messageHash, myPublicOutputs.Root);
  wallet.blockHash = msgInclusionPath.array[msgInclusionPath.array.length - 1] // The last element is the root

  // Call the function that wraps the zk-program call
  const result = await wallet.proveStateAfterSending(
    salt,
    msgInclusionPath,//prev
    msgInclusionPath,
    myPublicOutputs
  );

  //console.log('State proof (sendtx) result:', result);/**/

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);

  const proofInclusionPath = simulateMerklePaths(wallet.blockHash, salt);
  const blockHash = proofInclusionPath.array[proofInclusionPath.array.length - 1] // The last element is the root

  // Call the function that wraps the zk-program call
  const result2 = await wallet.proveTxAfterSending(
    blockHash,
    salt,
    proofInclusionPath,//prev
    myPublicOutputs
  );

  //console.log('Tx proof (sendtx) result:', result2);

  const isValid2 = await verify(result2.toJSON(), verificationKey);
  console.log('ok', isValid2);
}

async function testAbsorbTx(wallet: Wallet) {
  // Random initialization values for testing
  const amount = Field("5");
  const salt = wallet.destinationsRoot; //this should be changed

  const transactionDestination = wallet.Destinations[0];
  const transactionBalance = wallet.balance.sub(wallet.balanceNew); 
  console.log('transactionBalance of absorbing transaction:', transactionBalance.toString());

  // Simulate storing the previous state before the transaction
  const stateHashPrev = treeHasher.createMerkleTree([
    wallet.pkHash,
    wallet.address,
    wallet.destinationsRoot,
    wallet.balanceNew,
    wallet.inTxsRootNew,
    wallet.outTxsRoot
  ]);

  // Call the absorbNewTx function
  if(!wallet.absorbNewTx(transactionDestination, amount, salt, wallet.newTxProof)) {
    return;
  }

  const newStateHash = wallet.stateHashNew;
  const messageHash = treeHasher.createMerkleTree([wallet.address, wallet.stateHashNew]);
/*
  console.log('New state hash after absorbing transaction:', newStateHash.toString());
  console.log('wallet.blockHash:', wallet.blockHash.toString());
  console.log('wallet.prevStateProof.publicOutput.Leaf:', wallet.prevStateProof.publicOutput.Leaf.toString());
  console.log('wallet.prevStateProof.publicOutput.Root:', wallet.prevStateProof.publicOutput.Root.toString());
*/
  const myPublicOutputs = new MyPublicOutputs({
    Leaf: stateHashPrev, // Using the initial state hash as the leaf
    Root: wallet.blockHash // The last element is the root
  });

  // For verification purposes, simulate the transaction inclusion proof
  const inclusionPath = simulateMerklePaths(wallet.blockHash, messageHash);
  wallet.blockHash = inclusionPath.array[inclusionPath.array.length - 1] // The last element is the root

  console.log('wallet.blockHash:', wallet.blockHash.toString());
  console.log('messageHash:', messageHash.toString());

  // Call the function that wraps the zk-program call for verifying the new state
  const result = await wallet.proveStateAfterAbsorbing(
    transactionDestination,
    transactionBalance,
    salt,
    inclusionPath, // Using the same path for simplicity
    inclusionPath, // New path after the transaction is absorbed
    wallet.oldStateSnapshot!.newTxProof,
    myPublicOutputs
  );

  //console.log('Transaction absorption proof result:', result);

  const isValid = await verify(result.toJSON(), verificationKey);
  console.log('ok', isValid);
}
const treeHasher = new FastTree();
/*
const rt = treeHasher.createMerkleTree([Field(0), Field(0), Field(0), Field(0), Field(0), Field("16580941339322802610582068189301308321734543574938171559508035048394212433183"), Field(0)]);
  console.log('ok', rt.toString());
*/


// Function to log the Merkle tree root
function logRoot(tree: any) {
  console.log('Merkle Root:', tree.toString());
}

// Function to create a Merkle tree and log its root
function createAndLogTree(values: string[]) {
  const tree = treeHasher.createMerkleTree(values.map(Field));
  logRoot(tree);
  return tree;
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Function to call a Python script with interactive input
function callPythonScript(script: string, args: string[] = []): Promise<void> {
    return new Promise((resolve, reject) => {
        const process = spawn('python3', [script, ...args], {
            stdio: ['pipe', 'inherit', 'inherit']
        });

        rl.on('line', (input) => {
            process.stdin.write(input + '\n');
        });

        process.on('close', (code) => {
            rl.removeAllListeners('line');
            if (code !== 0) {
                reject(new Error(`Python script exited with code ${code}`));
            } else {
                resolve();
            }
        });
    });
}

// Function to wrap rl.question in a promise
function question(query: string): Promise<string> {
    return new Promise(resolve => rl.question(query, resolve));
}

async function interactive() {
    try {
        //await callPythonScript('load_wallet_state.py');
        await callPythonScript('show_keys.py');
        await callPythonScript('show_balance.py');

        while (true) {
            console.log("\nWallet Operations:");
            console.log("1. Show Balance");
            console.log("2. Transfer Funds");
            console.log("3. Stake Funds");
            console.log("4. Unstake Funds");
            console.log("5. Delete Wallet");
            console.log("6. Fund New Wallet");
            console.log("7. Initialize Hidden State");
            console.log("8. Send Stealth Transaction");
            console.log("9. Receive Stealth Transaction");
            console.log("10. Show Stealth Addresses");
            console.log("11. Show Stealth Balance");
            console.log("12. Transfer to Stealth");
            console.log("x. Exit");

            const choice = await question("Select an operation: ");

            try {
                switch (choice) {
                    case '1':
                        await callPythonScript('show_balance.py');
                        break;
                    case '2':
                        await callPythonScript('transfer.py');
                        break;
                    case '3':
                        await callPythonScript('stake.py');
                        break;
                    case '4':
                        await callPythonScript('unstake.py');
                        break;
                    case '5':
                        await callPythonScript('delete_wallet.py');
                        console.log("Exiting after deletion as no operations can be performed on a deleted wallet");
                        rl.close();
                        return;
                    case '6':
                        await callPythonScript('sponsor_create_account.py');
                        break;
                    case '7':
                        await callPythonScript('initialize_hidden_state.py');
                        break;
                    case '8':
                        await callPythonScript('send_stealth.py');
                        break;
                    case '9':
                        await callPythonScript('receive_stealth.py');
                        break;
                    case '10':
                        await callPythonScript('show_stealth_addresses.py');
                        break;
                    case '11':
                        await callPythonScript('show_stealth_balance.py');
                        break;
                    case '12':
                        await callPythonScript('transfer_with_burn_to_stealth.py');
                        break;
                    case 'x':
                    case 'X':
                        console.log("Exiting wallet application.");
                        rl.close();
                        return;
                    default:
                        console.log("Invalid choice, please select a valid operation.");
                }
            } catch (error) {
                console.error('Error:', error);
            }
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

async function main() {
    const args = process.argv.slice(2);
    if (args.length < 1) {
        await interactive();
        process.exit(1);
    }

    const functionToCall = args[0];
    const functionArgs = args.slice(1);

    try {
        switch (functionToCall) {
            case 'init':
                await callPythonScript('initialize_wallet.py');
                break;
            case 'keys':
                await callPythonScript('show_keys.py');
                break;
            case 'balance':
                await callPythonScript('show_balance.py');
                break;
            case 'delete':
                await callPythonScript('delete_wallet.py');
                break;
            case 'create':
                await callPythonScript('sponsor_create_account.py');
                break;
            case 'transfer':
                await callPythonScript('transfer.py');
                break;
            case 'stake':
                await callPythonScript('stake.py');
                break;
            case 'unstake':
                await callPythonScript('unstake.py');
                break;
            case 'update':
                await callPythonScript('update_state_hash.py');
                break;
            case 'send_stealth':
                await callPythonScript('send_stealth.py');
                break;
            case 'receive_stealth':
                await callPythonScript('receive_stealth.py');
                break;
            case 'show_stealth_addresses':
                await callPythonScript('show_stealth_addresses.py');
                break;
            case 'show_stealth_balance':
                await callPythonScript('show_stealth_balance.py');
                break;
            case 'transfer_to_stealth':
                await callPythonScript('transfer_with_burn_to_stealth.py');
                break;
            case 'help':
                console.log("Available commands: init, keys, balance, delete, create, transfer, stake, unstake, update, send_stealth, receive_stealth, show_stealth_addresses, show_stealth_balance, transfer_to_stealth");
                break;
            default:
                await interactive();
        }
    } catch (error) {
        console.error('Error:', error);
    }
}

await main();

process.exit(1);
console.log('compiling zkprogram...');
console.time('compile');

// Run the function to check, load or create the verification key
  let verificationKey: VerificationKey; // Declare the variable to store the verification key

    const compiled = await transitionProgram.compile();
    verificationKey = compiled.verificationKey;
console.timeEnd('compile');

console.log('testing init...');
console.time('init');
const wal = await testRandomInitialization();
console.timeEnd('init');
console.log('finished init...');

console.log('testing derive...');
console.time('derive');
await testDeriveDestination(wal);
console.timeEnd('derive');
console.log('finished derive...');

console.log('testing BurnToStealth...');
console.time('BurnToStealth');
await testBurnToStealth(wal);
console.timeEnd('BurnToStealth');
console.log('finished BurnToStealth...');

console.log('testing send...');
console.time('send');
await testSendTx(wal);
console.timeEnd('send');
console.log('finished send...');

console.log('testing receive...');
console.time('receive');
await testAbsorbTx(wal);
console.timeEnd('receive');
console.log('finished receive...');

console.log('testing BurnToStealth...');
console.time('BurnToStealth');
await testBurnToStealth(wal);
console.timeEnd('BurnToStealth');
console.log('finished BurnToStealth...');

console.log('testing derive...');
console.time('derive');
await testDeriveDestination(wal);
console.timeEnd('derive');
console.log('finished derive...');

console.log('testing send...');
console.time('send');
await testSendTx(wal);
console.timeEnd('send');
console.log('finished send...');

console.log('testing receive...');
console.time('receive');
await testAbsorbTx(wal);
console.timeEnd('receive');
console.log('finished receive...');

console.log('testing BurnToStealth...');
console.time('BurnToStealth');
await testBurnToStealth(wal);
console.timeEnd('BurnToStealth');
console.log('finished BurnToStealth...');

