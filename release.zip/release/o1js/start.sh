#!/bin/bash

# Define project name and source folder path
PROJECT_NAME="zkwallet"

# Install or update the zkApp CLI
npm install -g zkapp-cli

# Create a new zkApp project
zk project $PROJECT_NAME

# Change directory to the new project
cd $PROJECT_NAME
cd src
# Remove the generated src folder
rm -f *

# Move existing src folder to the project directory
mv ../../src/* .

cd ..

# Build the project
npm run build
