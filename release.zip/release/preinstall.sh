#!/bin/bash

# Function to install Go
install_go() {
  echo "Installing Go..."
  wget -c https://go.dev/dl/go1.21.1.linux-amd64.tar.gz -O - | sudo tar -xz -C /usr/local
  echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.profile
  source ~/.profile
  echo "Go installed successfully."
}

# Function to install Rust
install_rust() {
  echo "Installing Rust..."
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
  source $HOME/.cargo/env
  echo "Rust installed successfully."
}

# Function to install Node.js
install_node() {
  echo "Installing Node.js..."
  curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
  sudo apt-get install -y nodejs
  echo "Node.js installed successfully."
}

# Check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Install Go if not already installed
if command_exists go; then
  echo "Go is already installed."
else
  install_go
fi

# Install Rust if not already installed
if command_exists rustc; then
  echo "Rust is already installed."
else
  install_rust
fi

# Install Node.js if not already installed
if command_exists node; then
  echo "Node.js is already installed."
else
  install_node
fi

echo "All prerequisites are installed."
