#!/bin/bash

# Define the paths
ZKNODE_PATH="$HOME/go/apps/node/zknode"
ZKWALLET_PATH="$HOME/o1js/zkwallet/build/src/run.js"

# Check if zknode exists and is executable
if [[ -x "$ZKNODE_PATH" ]]; then
  # Run zknode in the background
  "$ZKNODE_PATH" &
else
  echo "Error: $ZKNODE_PATH does not exist or is not executable."
  exit 1
fi

# Check if zkwallet script exists
if [[ -f "$ZKWALLET_PATH" ]]; then
  # Run the zkwallet script with node
  node "$ZKWALLET_PATH"
else
  echo "Error: $ZKWALLET_PATH does not exist."
  exit 1
fi

