#!/bin/bash

# Function to install Go (requires sudo)
install_go() {
  echo "Installing Go..."
  sudo wget -c https://go.dev/dl/go1.21.1.linux-amd64.tar.gz -O - | sudo tar -xz -C /usr/local

  # Configure Go environment variables
  echo 'export PATH=$PATH:/usr/local/go/bin' >> ~/.profile
  echo 'export GOPATH=$HOME/go' >> ~/.profile
  echo 'export GOBIN=$GOPATH/bin' >> ~/.profile
  echo 'export PATH=$PATH:$GOBIN' >> ~/.profile

  # Create Go workspace directories
  mkdir -p $HOME/go/{bin,src,pkg}

  source ~/.profile
  echo "Go installed and workspace configured successfully."
}

# Function to configure Go workspace (even if Go is already installed)
configure_go_workspace() {
  echo "Configuring Go workspace..."

  # Ensure the Go workspace directories exist
  mkdir -p $HOME/go/{bin,src,pkg}

  # Ensure Go environment variables are set
  if ! grep -q 'export GOPATH=$HOME/go' ~/.profile; then
    echo 'export GOPATH=$HOME/go' >> ~/.profile
  fi
  if ! grep -q 'export GOBIN=$GOPATH/bin' ~/.profile; then
    echo 'export GOBIN=$GOPATH/bin' >> ~/.profile
  fi
  if ! grep -q 'export PATH=$PATH:$GOBIN' ~/.profile; then
    echo 'export PATH=$PATH:$GOBIN' >> ~/.profile
  fi

  echo "Go workspace configured successfully."
}

# Function to install Rust using rustup (runs as user, without sudo)
install_rust() {
  echo "Installing Rust..."

  # Remove any previous incomplete installations
  rm -rf $HOME/.cargo $HOME/.rustup

  # Install Rust using rustup (run as the current user, not with sudo)
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y

  # Ensure ~/.cargo/env is sourced correctly
  if [ -f "$HOME/.cargo/env" ]; then
    # Source the environment to update the current session
    source "$HOME/.cargo/env"

    # Export the PATH directly in this script
    export PATH="$HOME/.cargo/bin:$PATH"

    # Ensure the environment is set up for future sessions
    if ! grep -q 'source $HOME/.cargo/env' ~/.profile; then
      echo 'source $HOME/.cargo/env' >> ~/.profile
    fi
  else
    echo "Error: Rust installation failed or the environment file is missing."
    exit 1
  fi

  echo "Rust installed successfully."
}

# Function to install Node.js (requires sudo)
install_node() {
  echo "Installing Node.js..."

  if command_exists apt-get; then
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt-get install -y nodejs
  elif command_exists dnf; then
    curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
    sudo dnf install -y nodejs
  elif command_exists zypper; then
    sudo zypper install -y nodejs
  elif command_exists pacman; then
    sudo pacman -Sy --noconfirm nodejs npm
  else
    echo "Unsupported package manager. Please install Node.js manually."
    exit 1
  fi

  echo "Node.js installed successfully."
}

# Function to install a C compiler (requires sudo)
install_cc() {
  echo "Installing C compiler (GCC)..."

  if command_exists apt-get; then
    sudo apt-get update
    sudo apt-get install -y build-essential
  elif command_exists dnf; then
    sudo dnf install -y gcc gcc-c++
  elif command_exists zypper; then
    sudo zypper install -y gcc gcc-c++
  elif command_exists pacman; then
    sudo pacman -Sy --noconfirm gcc
  else
    echo "Unsupported package manager. Please install GCC or Clang manually."
    exit 1
  fi

  echo "C compiler (GCC) installed successfully."
}

# Function to install Git (requires sudo)
install_git() {
  echo "Installing Git..."

  if command_exists apt-get; then
    sudo apt-get update
    sudo apt-get install -y git
  elif command_exists dnf; then
    sudo dnf install -y git
  elif command_exists zypper; then
    sudo zypper install -y git
  elif command_exists pacman; then
    sudo pacman -Sy --noconfirm git
  else
    echo "Unsupported package manager. Please install Git manually."
    exit 1
  fi

  echo "Git installed successfully."
}

# Check if a command exists
command_exists() {
  command -v "$1" >/dev/null 2>&1
}

# Install Go if not already installed
if command_exists go; then
  echo "Go is already installed."
  configure_go_workspace  # Ensure the Go workspace is configured
else
  install_go
fi

# Install a C compiler if not already installed
if command_exists cc || command_exists gcc; then
  echo "C compiler is already installed."
else
  install_cc
fi

# Install Rust using rustup if not already installed (runs as user)
if command_exists rustc && command_exists cargo; then
  if rustc --version >/dev/null 2>&1 && cargo --version >/dev/null 2>&1; then
    echo "Rust and Cargo are already installed and functional."
  else
    echo "Rust or Cargo are not functioning properly. Reinstalling..."
    install_rust
  fi
else
  install_rust
fi

# Install Node.js if not already installed
if command_exists node; then
  echo "Node.js is already installed."
else
  install_node
fi

# Install Git if not already installed
if command_exists git; then
  echo "Git is already installed."
else
  install_git
fi

# Final check for Rust and Cargo
if command_exists cargo && command_exists rustc; then
  echo "Rust and Cargo are available."
else
  echo "Error: Rust installation failed."
  exit 1
fi

# Step 1: Define the path for the virtual environment directory in the home directory
VENV_DIR="$HOME/venv"

# Step 2: Check if the virtual environment directory exists, if not, create it
if [ ! -d "$VENV_DIR" ]; then
  echo "Creating virtual environment in $HOME..."
  python3 -m venv $VENV_DIR
else
  echo "Virtual environment already exists in $HOME."
fi

# Step 3: Activate the virtual environment
echo "Activating virtual environment..."
source $VENV_DIR/bin/activate

# Step 4: Install required packages
echo "Installing required packages..."
pip install requests

echo "All prerequisites are installed."
echo "To ensure Rust and Cargo are available in all future terminal sessions, please run:"
echo "source ~/.profile"
echo "To ensure python3 is available in all future terminal sessions, please run:"
echo "source $VENV_DIR/bin/activate"
