#!/bin/bash

# Define the paths
ZKNODE_PATH="$HOME/go/apps/node/"
ZKWALLET_PATH="o1js/zkwallet/build/src/"
LOG_FILE="$HOME/go/apps/node/run_output.log"  # Define the log file path
WALLET_STATE_FILE="${ZKWALLET_PATH}wallet_state.json"
WALLET_STATE_BACKUP="${ZKWALLET_PATH}wallet_state_backup.json"

# Save the current directory (this is where ZKWALLET_PATH is relative to)
ORIGINAL_DIR=$(pwd)

# Check if zknode exists and is executable
if [[ -x "${ZKNODE_PATH}run.sh" ]]; then  # Ensure you're checking the correct script
  pushd "$ZKNODE_PATH" > /dev/null  # Change to ZKNODE_PATH and save current directory
  # Run zknode in the background and redirect output to a log file
  ./run.sh > "$LOG_FILE" 2>&1 &
  echo "zknode is running in the background. Output is redirected to $LOG_FILE"
  popd > /dev/null  # Return to the original directory
else
  echo "Error: $ZKNODE_PATH/run.sh does not exist or is not executable."
  exit 1
fi

# Now you're back in the original directory
# Check if zkwallet directory exists and if run.js script exists inside it
if [[ -d "$ZKWALLET_PATH" && -f "${ZKWALLET_PATH}run.js" ]]; then
  # Backup the current wallet_state.json file
  if [[ -f "$WALLET_STATE_FILE" ]]; then
    cp "$WALLET_STATE_FILE" "$WALLET_STATE_BACKUP"
    echo "Backup of wallet_state.json created."
  else
    echo "Warning: $WALLET_STATE_FILE does not exist. No backup was created."
  fi

  # Run the zkwallet script with node
  cd "$ZKWALLET_PATH"
  node run.js
else
  echo "Error: $ZKWALLET_PATH or run.js does not exist."
  exit 1
fi

# Find the zknode process by name and kill it
ZKNODE_PID=$(pgrep -f zknode)

if [[ -n "$ZKNODE_PID" ]]; then
  if kill -9 $ZKNODE_PID > /dev/null 2>&1; then
    echo "zknode process with PID $ZKNODE_PID has been killed."
  else
    echo "Failed to kill zknode process with PID $ZKNODE_PID."
  fi
else
  echo "Error: Could not find zknode process by name."
fi

cd "$ORIGINAL_DIR"

# store the original wallet_state.json file if backup exists
if [[ -f "$WALLET_STATE_BACKUP" ]]; then
  mv "$WALLET_STATE_BACKUP" "$WALLET_STATE_FILE"
  echo "wallet_state.json restored to its original state."
else
  echo "Warning: No backup found. wallet_state.json was not restored."
fi
