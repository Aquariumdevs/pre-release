# zkSpace-wallet
A wallet for zkSpace
