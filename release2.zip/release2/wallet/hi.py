# example_script.py
print("Hello from Python!")
