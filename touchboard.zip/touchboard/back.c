#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <json-c/json.h>
#include <limits.h>
#include <ctype.h>
#include <sys/time.h>
#include <linux/input-event-codes.h>

#define CALIBRATION_FILE "/etc/touchpad_key_map.json"
#define DEVICE_PATH_FILE "device_path.json"
#define MAX_KEYS 29
#define TIME_WINDOW_MS 500
#define TAP_MAX_TIME 200
#define TAP_MAX_DISTANCE 20

typedef struct {
    char key;
    int keycode;
    int x;
    int y;
} KeyMapping;

KeyMapping key_map[MAX_KEYS];
int key_count = 0;
int caps_lock_enabled = 0;  // Flag for Caps Lock
int keyboard_enabled = 1;   // Flag to enable/disable the keyboard
int num_symbols_mode = 0;   // Flag for number/symbol mode

void trim_whitespace(char *str) {
    char *end;
    while (isspace((unsigned char)*str)) str++;
    if (*str == 0) return;
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;
    *(end + 1) = 0;
}

char* get_device_name(const char* device_path) {
    char* device_name = "My Touchpad";
    return strdup(device_name);
}

void save_device_path(const char *device_path) {
    struct json_object *jobj = json_object_new_object();
    json_object_object_add(jobj, "device_path", json_object_new_string(device_path));
    FILE *fp = fopen(DEVICE_PATH_FILE, "w");
    if (fp) {
        fprintf(fp, "%s", json_object_to_json_string_ext(jobj, JSON_C_TO_STRING_PRETTY));
        fclose(fp);
        printf("Device path saved.\n");
    } else {
        perror("Failed to save device path");
    }
    json_object_put(jobj);
}

char* load_device_path() {
    FILE *fp = fopen(DEVICE_PATH_FILE, "r");
    if (fp) {
        fseek(fp, 0, SEEK_END);
        long length = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        char *json_data = malloc(length);
        fread(json_data, 1, length, fp);
        fclose(fp);
        struct json_object *jobj = json_tokener_parse(json_data);
        struct json_object *jdevice_path;
        json_object_object_get_ex(jobj, "device_path", &jdevice_path);
        char *device_path = strdup(json_object_get_string(jdevice_path));
        free(json_data);
        json_object_put(jobj);
        return device_path;
    } else {
        return NULL;
    }
}

char* find_touchpad_device() {
    FILE *fp = fopen("/proc/bus/input/devices", "r");
    if (fp == NULL) {
        perror("Failed to open /proc/bus/input/devices");
        return NULL;
    }

    char line[256];
    char *device_path = NULL;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "Touchpad")) {
            while (fgets(line, sizeof(line), fp)) {
                if (strstr(line, "H: Handlers=")) {
                    char *event_pos = strstr(line, "event");
                    if (event_pos) {
                        char event_file[16];
                        sscanf(event_pos, "%s", event_file);
                        asprintf(&device_path, "/dev/input/%s", event_file);
                        break;
                    }
                }
            }
        }
    }

    fclose(fp);
    return device_path;
}

void save_calibration_data(const char* device_name) {
    printf("Saving calibration data...\n");
    if (device_name == NULL) {
        fprintf(stderr, "Error: device_name is NULL. Setting to default 'Unknown Device'.\n");
        device_name = "Unknown Device";
    }
    struct json_object *jobj = json_object_new_object();
    if (jobj == NULL) {
        fprintf(stderr, "Error: Failed to create JSON object.\n");
        return;
    }
    struct json_object *jarray = json_object_new_array();
    if (jarray == NULL) {
        fprintf(stderr, "Error: Failed to create JSON array.\n");
        json_object_put(jobj);
        return;
    }
    json_object_object_add(jobj, "device_name", json_object_new_string(device_name));
    for (int i = 0; i < key_count; i++) {
        struct json_object *jkey = json_object_new_object();
        if (jkey == NULL) {
            fprintf(stderr, "Error: Failed to create JSON object for key %c.\n", key_map[i].key);
            continue;
        }
        json_object_object_add(jkey, "key", json_object_new_string(&key_map[i].key));
        json_object_object_add(jkey, "keycode", json_object_new_int(key_map[i].keycode));
        json_object_object_add(jkey, "x", json_object_new_int(key_map[i].x));
        json_object_object_add(jkey, "y", json_object_new_int(key_map[i].y));
        json_object_array_add(jarray, jkey);
    }
    json_object_object_add(jobj, "keys", jarray);
    FILE *fp = fopen(CALIBRATION_FILE, "w");
    if (fp == NULL) {
        perror("Failed to open calibration file for writing");
        json_object_put(jobj);
        return;
    }
    if (fprintf(fp, "%s", json_object_to_json_string_ext(jobj, JSON_C_TO_STRING_PRETTY)) < 0) {
        perror("Failed to write calibration data to file");
    }
    fclose(fp);
    json_object_put(jobj);
    printf("Calibration data saved successfully.\n");
}

int check_calibration_file_exists() {
    printf("Checking if calibration data file exists at path: %s\n", CALIBRATION_FILE);

    FILE *fp = fopen(CALIBRATION_FILE, "r");
    if (fp == NULL) {
        printf("Calibration data file does not exist or cannot be opened.\n");
        perror("fopen");
        return 0;
    }

    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (file_size == 0) {
        printf("Calibration data file is empty. Treating as non-existent.\n");
        fclose(fp);
        return 0;
    }

    printf("Calibration data file found with size: %ld bytes\n", file_size);
    fclose(fp);
    return 1;
}

void load_calibration_data(char** device_name) {
    FILE *fp = fopen(CALIBRATION_FILE, "r");
    if (fp) {
        fseek(fp, 0, SEEK_END);
        long length = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        char *json_data = malloc(length);
        fread(json_data, 1, length, fp);
        fclose(fp);
        struct json_object *jobj = json_tokener_parse(json_data);
        struct json_object *jarray;
        json_object_object_get_ex(jobj, "keys", &jarray);
        struct json_object *jdevice_name;
        json_object_object_get_ex(jobj, "device_name", &jdevice_name);
        *device_name = strdup(json_object_get_string(jdevice_name));
        key_count = json_object_array_length(jarray);
        for (int i = 0; i < key_count; i++) {
            struct json_object *jkey = json_object_array_get_idx(jarray, i);
            struct json_object *jkey_value;
            json_object_object_get_ex(jkey, "key", &jkey_value);
            key_map[i].key = json_object_get_string(jkey_value)[0];
            json_object_object_get_ex(jkey, "keycode", &jkey_value);
            key_map[i].keycode = json_object_get_int(jkey_value);
            json_object_object_get_ex(jkey, "x", &jkey_value);
            key_map[i].x = json_object_get_int(jkey_value);
            json_object_object_get_ex(jkey, "y", &jkey_value);
            key_map[i].y = json_object_get_int(jkey_value);
        }
        free(json_data);
        json_object_put(jobj);
    } else {
        perror("Failed to load calibration data");
    }
}

void initialize_key_map(KeyMapping *key_map) {
    key_map[0].key = 'A'; key_map[0].keycode = KEY_A;
    key_map[1].key = 'B'; key_map[1].keycode = KEY_B;
    key_map[2].key = 'C'; key_map[2].keycode = KEY_C;
    key_map[3].key = 'D'; key_map[3].keycode = KEY_D;
    key_map[4].key = 'E'; key_map[4].keycode = KEY_E;
    key_map[5].key = 'F'; key_map[5].keycode = KEY_F;
    key_map[6].key = 'G'; key_map[6].keycode = KEY_G;
    key_map[7].key = 'H'; key_map[7].keycode = KEY_H;
    key_map[8].key = 'I'; key_map[8].keycode = KEY_I;
    key_map[9].key = 'J'; key_map[9].keycode = KEY_J;
    key_map[10].key = 'K'; key_map[10].keycode = KEY_K;
    key_map[11].key = 'L'; key_map[11].keycode = KEY_L;
    key_map[12].key = 'M'; key_map[12].keycode = KEY_M;
    key_map[13].key = 'N'; key_map[13].keycode = KEY_N;
    key_map[14].key = 'O'; key_map[14].keycode = KEY_O;
    key_map[15].key = 'P'; key_map[15].keycode = KEY_P;
    key_map[16].key = 'Q'; key_map[16].keycode = KEY_Q;
    key_map[17].key = 'R'; key_map[17].keycode = KEY_R;
    key_map[18].key = 'S'; key_map[18].keycode = KEY_S;
    key_map[19].key = 'T'; key_map[19].keycode = KEY_T;
    key_map[20].key = 'U'; key_map[20].keycode = KEY_U;
    key_map[21].key = 'V'; key_map[21].keycode = KEY_V;
    key_map[22].key = 'W'; key_map[22].keycode = KEY_W;
    key_map[23].key = 'X'; key_map[23].keycode = KEY_X;
    key_map[24].key = 'Y'; key_map[24].keycode = KEY_Y;
    key_map[25].key = 'Z'; key_map[25].keycode = KEY_Z;
    key_map[26].key = 'c'; key_map[26].keycode = KEY_CAPSLOCK; // Caps Lock
    key_map[27].key = 'n'; key_map[27].keycode = KEY_NUMLOCK;  // Numbers/Symbols Toggle
    key_map[28].key = 't'; key_map[28].keycode = KEY_LEFTCTRL; // Enable/Disable Keyboard Toggle
}

long get_current_time_ms() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

int compare_ints(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

int median(int values[], int count) {
    qsort(values, count, sizeof(int), compare_ints);
    if (count % 2 == 0) {
        return (values[count / 2 - 1] + values[count / 2]) / 2;
    } else {
        return values[count / 2];
    }
}

void calibrate_device(FILE *fp) {
    char keys[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZcnt"; // 'C' for Caps Lock, 'n' for Numbers/Symbols, 't' for Toggle
    const char* special_keys[] = {
        "Caps Lock",
        "Numbers/Symbols Toggle",
        "Enable/Disable Keyboard Toggle"
    };
    struct input_event ev;
    int x_values[100], y_values[100];
    int x_index, y_index;
    long start_time;
    initialize_key_map(key_map);
    key_count = 0;

    for (int i = 0; i < MAX_KEYS; i++) {
        int valid_touch = 0;
        while (!valid_touch) {
            if (i >= 26) {
                printf("Calibrating for special key '%s' (index %d)...\n", special_keys[i - 26], i);
            } else {
                printf("Calibrating for key '%c' (index %d)...\n", keys[i], i);
            }
            x_index = y_index = 0;
            start_time = get_current_time_ms();
            int x_start = 0, y_start = 0, x_end = 0, y_end = 0;
            int x_start_recorded = 0, y_start_recorded = 0;
            long touch_start_time = 0, touch_end_time = 0;

            while (get_current_time_ms() - start_time < TIME_WINDOW_MS) {
                if (fread(&ev, sizeof(struct input_event), 1, fp) == 1) {
                    if (ev.type == EV_ABS) {
                        if (ev.code == ABS_X) {
                            if (!x_start_recorded) {
                                x_start = ev.value;
                                x_start_recorded = 1;
                            }
                            x_end = ev.value;
                            x_values[x_index++] = ev.value;
                        } else if (ev.code == ABS_Y) {
                            if (!y_start_recorded) {
                                y_start = ev.value;
                                y_start_recorded = 1;
                            }
                            y_end = ev.value;
                            y_values[y_index++] = ev.value;
                        }
                    } else if (ev.type == EV_KEY && ev.code == BTN_TOUCH) {
                        if (ev.value == 1) {
                            touch_start_time = get_current_time_ms();
                        } else if (ev.value == 0 && touch_start_time > 0) {
                            touch_end_time = get_current_time_ms();
                            long touch_duration = touch_end_time - touch_start_time;
                            int distance = abs(x_end - x_start) + abs(y_end - y_start);

                            if (touch_duration <= TAP_MAX_TIME && distance <= TAP_MAX_DISTANCE) {
                                valid_touch = 1;
                                break;
                            } else {
                                printf("Swipe detected. Retrying calibration for key '%c'.\n", keys[i]);
                                valid_touch = 0;
                                break;
                            }
                        }
                    }
                }
            }

            if (valid_touch) {
                if (x_index > 0 && y_index > 0) {
                    key_map[key_count].key = keys[i];
                    key_map[key_count].x = median(x_values, x_index);
                    key_map[key_count].y = median(y_values, y_index);
                    printf("Key '%c': x=%d, y=%d\n", keys[i], key_map[key_count].x, key_map[key_count].y);
                    key_count++;
                } else {
                    printf("No valid touches detected for key '%c'. Retrying.\n", keys[i]);
                }
            }
        }
    }
    printf("Calibration completed. Total keys calibrated: %d\n", key_count);
}

int calculate_euclidean_distance_squared(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    return dx * dx + dy * dy;
}

int find_closest_key(int x, int y) {
    int closest_key_index = -1;
    int min_distance = INT_MAX;

    printf("Finding closest key for coordinates: x=%d, y=%d\n", x, y);

    for (int i = 0; i < key_count; i++) {
        int distance = calculate_euclidean_distance_squared(x, y, key_map[i].x, key_map[i].y);
        printf("Checking key '%c': distance=%d, current min_distance=%d\n", key_map[i].key, distance, min_distance);
        if (distance < min_distance) {
            min_distance = distance;
            closest_key_index = i;
            printf("Key '%c' is currently the closest.\n", key_map[i].key);
        }
    }

    return closest_key_index != -1 ? closest_key_index : -1;
}

int get_mapped_keycode(int key_index, int *shift_required) {
    char key = key_map[key_index].key;

    *shift_required = 0;

    // Caps Lock should just send the keycode for Caps Lock
    if (key == 'c') {
        return KEY_CAPSLOCK;
    }

    // Toggle Num/Symbol mode
    if (key == 'n') {
        return KEY_NUMLOCK;
    }

    // Toggle keyboard enable/disable
    if (key == 't') {
        return KEY_LEFTCTRL;
    }

    if (num_symbols_mode) {
        // Handle special characters and numbers
        switch (key) {
            case 'A': return KEY_1;    // 1
            case 'B': return KEY_2;    // 2
            case 'C': return KEY_3;    // 3
            case 'D': return KEY_4;    // 4
            case 'E': return KEY_5;    // 5
            case 'F': return KEY_6;    // 6
            case 'G': return KEY_7;    // 7
            case 'H': return KEY_8;    // 8
            case 'I': return KEY_9;    // 9
            case 'J': return KEY_0;    // 0
            case 'K': return KEY_MINUS;    // -
            case 'L': return KEY_EQUAL;    // =
            case 'M': return KEY_LEFTBRACE; // [
            case 'N': return KEY_RIGHTBRACE; // ]
            case 'O': return KEY_BACKSLASH; // \
            case 'P': return KEY_SEMICOLON; // ;
            case 'Q': return KEY_APOSTROPHE; // '
            case 'R': return KEY_COMMA; // ,
            case 'S': return KEY_DOT;   // .
            case 'T': return KEY_SLASH; // /
            case 'U': return KEY_GRAVE;  // `
            default: return KEY_UNKNOWN;
        }
    }

    // Default to the regular keycode
    return key_map[key_index].keycode;
}

void send_key_event(int fd, int keycode, int value) {
    struct input_event event;
    memset(&event, 0, sizeof(struct input_event));
    event.type = EV_KEY;
    event.code = keycode;
    event.value = value;
    write(fd, &event, sizeof(struct input_event));

    // Sync event
    memset(&event, 0, sizeof(struct input_event));
    event.type = EV_SYN;
    event.code = SYN_REPORT;
    event.value = 0;
    write(fd, &event, sizeof(struct input_event));
}

void enter_input_mode(FILE *fp, int fd) {
    struct input_event ev;
    int x_start = 0, y_start = 0;
    int x_end = 0, y_end = 0;
    long touch_start_time = 0, touch_end_time = 0;
    int keycode;
    int shift_required;
    int x_start_recorded = 0; // Indicates whether the initial x coordinate has been recorded
    int y_start_recorded = 0; // Indicates whether the initial y coordinate has been recorded

    printf("Entering input mode...\n");

    while (fread(&ev, sizeof(struct input_event), 1, fp) > 0) {
        if (ev.type == EV_ABS) {
            if (ev.code == ABS_X) {
                if (!x_start_recorded) {
                    x_start = ev.value;
                    x_start_recorded = 1;
                }
                x_end = ev.value;
                printf("X coordinate: %d\n", x_end);
            } else if (ev.code == ABS_Y) {
                if (!y_start_recorded) {
                    y_start = ev.value;
                    y_start_recorded = 1;
                }
                y_end = ev.value;
                printf("Y coordinate: %d\n", y_end);
            }
        } else if (ev.type == EV_KEY && ev.code == BTN_TOUCH) {
            if (ev.value == 1) {
                touch_start_time = get_current_time_ms();
                printf("Touch started at x=%d, y=%d\n", x_start, y_start);
            } else if (ev.value == 0 && touch_start_time > 0) {
                touch_end_time = get_current_time_ms();
                long touch_duration = touch_end_time - touch_start_time;

                int distance = calculate_euclidean_distance_squared(x_start, y_start, x_end, y_end);

                printf("Touch ended at x=%d, y=%d\n", x_end, y_end);
                printf("Touch duration: %ld ms, Distance: %d\n", touch_duration, distance);

                if (touch_duration <= TAP_MAX_TIME && distance <= TAP_MAX_DISTANCE * TAP_MAX_DISTANCE) {
                    int key_index = find_closest_key(x_end, y_end);
                    if (key_index != -1) {
                        char key = key_map[key_index].key;

                        if (key == 't') {
                            keyboard_enabled = !keyboard_enabled;
                            printf("Keyboard %s.\n", keyboard_enabled ? "enabled" : "disabled");
                        } else if (keyboard_enabled) {
                            if (key == 'c') {
                                keycode = get_mapped_keycode(key_index, &shift_required);
                                printf("Toggling Caps Lock, keycode %d\n", keycode);
                                send_key_event(fd, keycode, 1);
                                send_key_event(fd, keycode, 0);
                            } else if (key == 'n') {
                                num_symbols_mode = !num_symbols_mode;
                                printf("Numbers/Symbols mode %s.\n", num_symbols_mode ? "enabled" : "disabled");
                            } else {
                                keycode = get_mapped_keycode(key_index, &shift_required);

                                printf("Sending keycode %d for key '%c'\n", keycode, key);

                                // Send key press
                                send_key_event(fd, keycode, 1);

                                // Send key release
                                send_key_event(fd, keycode, 0);
                            }
                        }
                    } else {
                        printf("No key mapped to this touch.\n");
                    }
                } else {
                    printf("Touch was not a valid tap (swipe detected).\n");
                }

                touch_start_time = 0;
                x_start_recorded = 0;
                y_start_recorded = 0;
            }
        }
    }
}

int main() {
    char *device_name = NULL;
    char *device_path = load_device_path();
    int fd = -1;

    if (device_path == NULL) {
        printf("No saved device path found. Attempting to identify the touchpad device...\n");
        device_path = find_touchpad_device();

        if (device_path == NULL) {
            fprintf(stderr, "Failed to identify the touchpad device. Exiting...\n");
            return EXIT_FAILURE;
        }

        printf("Touchpad device identified: %s\n", device_path);
        save_device_path(device_path);
    }

    trim_whitespace(device_path);
    printf("Attempting to open device at path: '%s' with fopen()...\n", device_path);
    device_name = get_device_name(device_path);

    FILE *fp = fopen(device_path, "r");
    if (fp == NULL) {
        perror("Failed to open input device with fopen");
        return EXIT_FAILURE;
    }

    if (!check_calibration_file_exists()) {
        printf("Calibration data not found. Starting calibration...\n");
        calibrate_device(fp);
        save_calibration_data(device_name);
    } else {
        printf("Calibration data found. Loading and starting virtual keyboard...\n");
        load_calibration_data(&device_name);

        fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
        if (fd < 0) {
            perror("Failed to open /dev/uinput");
            fclose(fp);
            return EXIT_FAILURE;
        }

        if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) {
            perror("Failed to set EV_KEY");
            close(fd);
            fclose(fp);
            return EXIT_FAILURE;
        }

        // Add support for all key codes
        for (int code = KEY_ESC; code <= KEY_MICMUTE; code++) {
            if (ioctl(fd, UI_SET_KEYBIT, code) < 0) {
                perror("Failed to set keybit");
                close(fd);
                fclose(fp);
                return EXIT_FAILURE;
            }
        }

        struct uinput_setup usetup;
        memset(&usetup, 0, sizeof(usetup));
        usetup.id.bustype = BUS_USB;
        usetup.id.vendor  = 0x1234;
        usetup.id.product = 0x5678;
        strcpy(usetup.name, "Virtual Touchpad Keyboard");

        if (ioctl(fd, UI_DEV_SETUP, &usetup) < 0) {
            perror("Failed to setup uinput device");
            close(fd);
            fclose(fp);
            return EXIT_FAILURE;
        }

        if (ioctl(fd, UI_DEV_CREATE) < 0) {
            perror("Failed to create uinput device");
            close(fd);
            fclose(fp);
            return EXIT_FAILURE;
        }

        enter_input_mode(fp, fd);

        if (ioctl(fd, UI_DEV_DESTROY) < 0) {
            perror("Failed to destroy uinput device");
        }

        close(fd);
    }

    fclose(fp);
    free(device_name);
    free(device_path);
    printf("Program completed without segmentation faults.\n");
    return 0;
}
