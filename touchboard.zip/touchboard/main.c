#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/uinput.h>
#include <fcntl.h>
#include <unistd.h>
#include <json-c/json.h>
#include <limits.h>
#include <ctype.h>
#include <sys/time.h>
#include <linux/input-event-codes.h>

#define CALIBRATION_FILE "/etc/touchpad_key_map.json"
#define DEVICE_PATH_FILE "device_path.json"
#define MAX_KEYS 39
#define TIME_WINDOW_MS 500
#define TAP_MAX_TIME 200
#define TAP_MAX_DISTANCE 20

typedef struct {
    char key;
    int keycode;
    int x;
    int y;
} KeyMapping;

KeyMapping key_map[MAX_KEYS];
int key_count = 0;
int caps_lock_enabled = 0;  // Flag for Caps Lock
int keyboard_enabled = 1;   // Flag to enable/disable the keyboard
int num_symbols_mode = 0;   // Flag for symbol mode
int touchpad_device_id = -1; // Touchpad device ID for xinput control

int keycodes_to_enable[] = {
    // Numbers
    KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6, KEY_7, KEY_8, KEY_9, KEY_0,

    // Symbols
    KEY_MINUS, KEY_EQUAL, KEY_LEFTBRACE, KEY_RIGHTBRACE, KEY_BACKSLASH,
    KEY_SEMICOLON, KEY_APOSTROPHE, KEY_COMMA, KEY_DOT, KEY_SLASH,
    KEY_GRAVE,
    KEY_SPACE, KEY_TAB,

    // Shifted Symbols
    KEY_LEFTSHIFT,  // To enable Shift for shifted symbols
    KEY_RIGHTSHIFT, // To enable Right Shift

    // You need to define keycodes for shifted symbols explicitly:
    // !, @, #, $, %, ^, &, *, (, )
    KEY_1 | 0x100, KEY_2 | 0x100, KEY_3 | 0x100, KEY_4 | 0x100,
    KEY_5 | 0x100, KEY_6 | 0x100, KEY_7 | 0x100, KEY_8 | 0x100,
    KEY_9 | 0x100, KEY_0 | 0x100,

    // ~, _, +, {, }, |, :, ", <, >, ?
    KEY_GRAVE | 0x100, KEY_MINUS | 0x100, KEY_EQUAL | 0x100,
    KEY_LEFTBRACE | 0x100, KEY_RIGHTBRACE | 0x100, KEY_BACKSLASH | 0x100,
    KEY_SEMICOLON | 0x100, KEY_APOSTROPHE | 0x100, KEY_COMMA | 0x100,
    KEY_DOT | 0x100, KEY_SLASH | 0x100,

    // Letters (which can also be used for other symbols in combination with shift/alt)
    KEY_A, KEY_B, KEY_C, KEY_D, KEY_E, KEY_F, KEY_G,
    KEY_H, KEY_I, KEY_J, KEY_K, KEY_L, KEY_M, KEY_N,
    KEY_O, KEY_P, KEY_Q, KEY_R, KEY_S, KEY_T,
    KEY_U, KEY_V, KEY_W, KEY_X, KEY_Y, KEY_Z,

    // Control keys
    KEY_CAPSLOCK, KEY_NUMLOCK, KEY_LEFTCTRL, KEY_LEFTALT, KEY_RIGHTALT, KEY_RIGHTCTRL
};

// Function to execute shell commands and retrieve output
char* exec_command(const char* cmd) {
    char buffer[128];
    char* result = NULL;
    size_t size = 1; // start with size 1 for null terminator
    FILE* pipe = popen(cmd, "r");

    if (!pipe) return NULL;

    while (fgets(buffer, sizeof(buffer), pipe) != NULL) {
        size_t buffer_len = strlen(buffer);
        result = realloc(result, size + buffer_len);
        if (!result) {
            pclose(pipe);
            return NULL;
        }
        strcpy(result + size - 1, buffer);
        size += buffer_len;
    }
    pclose(pipe);
    return result;
}

// Function to find touchpad device ID using xinput
int get_touchpad_device_id() {
    char* xinput_list = exec_command("xinput list");
    if (!xinput_list) {
        printf("Unable to list input devices.\n");
        return -1;
    }

    char* touchpad_line = strstr(xinput_list, "Touchpad");
    if (!touchpad_line) {
        printf("Touchpad device not found.\n");
        free(xinput_list);
        return -1;
    }

    char* id_pos = strstr(touchpad_line, "id=");
    if (!id_pos) {
        printf("Touchpad ID not found.\n");
        free(xinput_list);
        return -1;
    }

    int id;
    sscanf(id_pos, "id=%d", &id);

    free(xinput_list);
    return id;
}

// Function to disable the touchpad using xinput
void disable_touchpad(int device_id) {
    if (device_id != -1) {
        char command[256];
        sprintf(command, "xinput --disable %d", device_id);
        system(command);
        printf("Touchpad disabled.\n");
    }
}

// Function to enable the touchpad using xinput
void enable_touchpad(int device_id) {
    if (device_id != -1) {
        char command[256];
        sprintf(command, "xinput --enable %d", device_id);
        system(command);
        printf("Touchpad enabled.\n");
    }
}

void trim_whitespace(char *str) {
    char *end;
    while (isspace((unsigned char)*str)) str++;
    if (*str == 0) return;
    end = str + strlen(str) - 1;
    while (end > str && isspace((unsigned char)*end)) end--;
    *(end + 1) = 0;
}

char* get_device_name(const char* device_path) {
    char* device_name = "My Touchpad";
    return strdup(device_name);
}

void save_device_path(const char *device_path) {
    struct json_object *jobj = json_object_new_object();
    json_object_object_add(jobj, "device_path", json_object_new_string(device_path));
    FILE *fp = fopen(DEVICE_PATH_FILE, "w");
    if (fp) {
        fprintf(fp, "%s", json_object_to_json_string_ext(jobj, JSON_C_TO_STRING_PRETTY));
        fclose(fp);
        printf("Device path saved.\n");
    } else {
        perror("Failed to save device path");
    }
    json_object_put(jobj);
}

char* load_device_path() {
    FILE *fp = fopen(DEVICE_PATH_FILE, "r");
    if (fp) {
        fseek(fp, 0, SEEK_END);
        long length = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        char *json_data = malloc(length);
        fread(json_data, 1, length, fp);
        fclose(fp);
        struct json_object *jobj = json_tokener_parse(json_data);
        struct json_object *jdevice_path;
        json_object_object_get_ex(jobj, "device_path", &jdevice_path);
        char *device_path = strdup(json_object_get_string(jdevice_path));
        free(json_data);
        json_object_put(jobj);
        return device_path;
    } else {
        return NULL;
    }
}

char* find_touchpad_device() {
    FILE *fp = fopen("/proc/bus/input/devices", "r");
    if (fp == NULL) {
        perror("Failed to open /proc/bus/input/devices");
        return NULL;
    }

    char line[256];
    char *device_path = NULL;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "Touchpad")) {
            while (fgets(line, sizeof(line), fp)) {
                if (strstr(line, "H: Handlers=")) {
                    char *event_pos = strstr(line, "event");
                    if (event_pos) {
                        char event_file[16];
                        sscanf(event_pos, "%s", event_file);
                        asprintf(&device_path, "/dev/input/%s", event_file);
                        break;
                    }
                }
            }
        }
    }

    fclose(fp);
    return device_path;
}

void save_calibration_data(const char* device_name) {
    printf("Saving calibration data...\n");
    if (device_name == NULL) {
        fprintf(stderr, "Error: device_name is NULL. Setting to default 'Unknown Device'.\n");
        device_name = "Unknown Device";
    }
    struct json_object *jobj = json_object_new_object();
    if (jobj == NULL) {
        fprintf(stderr, "Error: Failed to create JSON object.\n");
        return;
    }
    struct json_object *jarray = json_object_new_array();
    if (jarray == NULL) {
        fprintf(stderr, "Error: Failed to create JSON array.\n");
        json_object_put(jobj);
        return;
    }
    json_object_object_add(jobj, "device_name", json_object_new_string(device_name));
    for (int i = 0; i < key_count; i++) {
        struct json_object *jkey = json_object_new_object();
        if (jkey == NULL) {
            fprintf(stderr, "Error: Failed to create JSON object for key %c.\n", key_map[i].key);
            continue;
        }
        json_object_object_add(jkey, "key", json_object_new_string(&key_map[i].key));
        json_object_object_add(jkey, "keycode", json_object_new_int(key_map[i].keycode));
        json_object_object_add(jkey, "x", json_object_new_int(key_map[i].x));
        json_object_object_add(jkey, "y", json_object_new_int(key_map[i].y));
        json_object_array_add(jarray, jkey);
    }
    json_object_object_add(jobj, "keys", jarray);
    FILE *fp = fopen(CALIBRATION_FILE, "w");
    if (fp == NULL) {
        perror("Failed to open calibration file for writing");
        json_object_put(jobj);
        return;
    }
    if (fprintf(fp, "%s", json_object_to_json_string_ext(jobj, JSON_C_TO_STRING_PRETTY)) < 0) {
        perror("Failed to write calibration data to file");
    }
    fclose(fp);
    json_object_put(jobj);
    printf("Calibration data saved successfully.\n");
}

int check_calibration_file_exists() {
    printf("Checking if calibration data file exists at path: %s\n", CALIBRATION_FILE);

    FILE *fp = fopen(CALIBRATION_FILE, "r");
    if (fp == NULL) {
        printf("Calibration data file does not exist or cannot be opened.\n");
        perror("fopen");
        return 0;
    }

    fseek(fp, 0, SEEK_END);
    long file_size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (file_size == 0) {
        printf("Calibration data file is empty. Treating as non-existent.\n");
        fclose(fp);
        return 0;
    }

    printf("Calibration data file found with size: %ld bytes\n", file_size);
    fclose(fp);
    return 1;
}

void load_calibration_data(char** device_name) {
    FILE *fp = fopen(CALIBRATION_FILE, "r");
    if (fp) {
        fseek(fp, 0, SEEK_END);
        long length = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        char *json_data = malloc(length);
        fread(json_data, 1, length, fp);
        fclose(fp);
        struct json_object *jobj = json_tokener_parse(json_data);
        struct json_object *jarray;
        json_object_object_get_ex(jobj, "keys", &jarray);
        struct json_object *jdevice_name;
        json_object_object_get_ex(jobj, "device_name", &jdevice_name);
        *device_name = strdup(json_object_get_string(jdevice_name));
        key_count = json_object_array_length(jarray);
        for (int i = 0; i < key_count; i++) {
            struct json_object *jkey = json_object_array_get_idx(jarray, i);
            struct json_object *jkey_value;
            json_object_object_get_ex(jkey, "key", &jkey_value);
            key_map[i].key = json_object_get_string(jkey_value)[0];
            json_object_object_get_ex(jkey, "keycode", &jkey_value);
            key_map[i].keycode = json_object_get_int(jkey_value);
            json_object_object_get_ex(jkey, "x", &jkey_value);
            key_map[i].x = json_object_get_int(jkey_value);
            json_object_object_get_ex(jkey, "y", &jkey_value);
            key_map[i].y = json_object_get_int(jkey_value);
        }
        free(json_data);
        json_object_put(jobj);
    } else {
        perror("Failed to load calibration data");
    }
}

void initialize_key_map(KeyMapping *key_map) {
    key_map[0].key = '1'; key_map[0].keycode = KEY_1;
    key_map[1].key = '2'; key_map[1].keycode = KEY_2;
    key_map[2].key = '3'; key_map[2].keycode = KEY_3;
    key_map[3].key = '4'; key_map[3].keycode = KEY_4;
    key_map[4].key = '5'; key_map[4].keycode = KEY_5;
    key_map[5].key = '6'; key_map[5].keycode = KEY_6;
    key_map[6].key = '7'; key_map[6].keycode = KEY_7;
    key_map[7].key = '8'; key_map[7].keycode = KEY_8;
    key_map[8].key = '9'; key_map[8].keycode = KEY_9;
    key_map[9].key = '0'; key_map[9].keycode = KEY_0;
    key_map[10].key = 'A'; key_map[10].keycode = KEY_A;
    key_map[11].key = 'B'; key_map[11].keycode = KEY_B;
    key_map[12].key = 'C'; key_map[12].keycode = KEY_C;
    key_map[13].key = 'D'; key_map[13].keycode = KEY_D;
    key_map[14].key = 'E'; key_map[14].keycode = KEY_E;
    key_map[15].key = 'F'; key_map[15].keycode = KEY_F;
    key_map[16].key = 'G'; key_map[16].keycode = KEY_G;
    key_map[17].key = 'H'; key_map[17].keycode = KEY_H;
    key_map[18].key = 'I'; key_map[18].keycode = KEY_I;
    key_map[19].key = 'J'; key_map[19].keycode = KEY_J;
    key_map[20].key = 'K'; key_map[20].keycode = KEY_K;
    key_map[21].key = 'L'; key_map[21].keycode = KEY_L;
    key_map[22].key = 'M'; key_map[22].keycode = KEY_M;
    key_map[23].key = 'N'; key_map[23].keycode = KEY_N;
    key_map[24].key = 'O'; key_map[24].keycode = KEY_O;
    key_map[25].key = 'P'; key_map[25].keycode = KEY_P;
    key_map[26].key = 'Q'; key_map[26].keycode = KEY_Q;
    key_map[27].key = 'R'; key_map[27].keycode = KEY_R;
    key_map[28].key = 'S'; key_map[28].keycode = KEY_S;
    key_map[29].key = 'T'; key_map[29].keycode = KEY_T;
    key_map[30].key = 'U'; key_map[30].keycode = KEY_U;
    key_map[31].key = 'V'; key_map[31].keycode = KEY_V;
    key_map[32].key = 'W'; key_map[32].keycode = KEY_W;
    key_map[33].key = 'X'; key_map[33].keycode = KEY_X;
    key_map[34].key = 'Y'; key_map[34].keycode = KEY_Y;
    key_map[35].key = 'Z'; key_map[35].keycode = KEY_Z;
    key_map[36].key = 'c'; key_map[36].keycode = KEY_CAPSLOCK; // Caps Lock
    key_map[37].key = 'n'; key_map[37].keycode = KEY_NUMLOCK;  // Numbers/Symbols Toggle
    key_map[38].key = 't'; key_map[38].keycode = KEY_LEFTCTRL; // Enable/Disable Keyboard Toggle
}

long get_current_time_ms() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

int compare_ints(const void *a, const void *b) {
    return (*(int *)a - *(int *)b);
}

int median(int values[], int count) {
    qsort(values, count, sizeof(int), compare_ints);
    if (count % 2 == 0) {
        return (values[count / 2 - 1] + values[count / 2]) / 2;
    } else {
        return values[count / 2];
    }
}

void calibrate_device(FILE *fp) {
    char keys[] = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZcnt";
    const char* special_keys[] = {
        "Caps Lock",
        "Numbers/Symbols Toggle",
        "Enable/Disable Keyboard Toggle"
    };
    struct input_event ev;
    int x_values[100], y_values[100];
    int x_index, y_index;
    long start_time;
    initialize_key_map(key_map);
    key_count = 0;

    for (int i = 0; i < MAX_KEYS; i++) {
        int valid_touch = 0;
        while (!valid_touch) {
            if (i >= 36) {
                printf("Calibrating for special key '%s' (index %d)...\n", special_keys[i - 36], i);
            } else {
                printf("Calibrating for key '%c' (index %d)...\n", keys[i], i);
            }
            x_index = y_index = 0;
            start_time = get_current_time_ms();
            int x_start = 0, y_start = 0, x_end = 0, y_end = 0;
            int x_start_recorded = 0, y_start_recorded = 0;
            long touch_start_time = 0, touch_end_time = 0;

            while (get_current_time_ms() - start_time < TIME_WINDOW_MS) {
                if (fread(&ev, sizeof(struct input_event), 1, fp) == 1) {
                    if (ev.type == EV_ABS) {
                        if (ev.code == ABS_X) {
                            if (!x_start_recorded) {
                                x_start = ev.value;
                                x_start_recorded = 1;
                            }
                            x_end = ev.value;
                            x_values[x_index++] = ev.value;
                        } else if (ev.code == ABS_Y) {
                            if (!y_start_recorded) {
                                y_start = ev.value;
                                y_start_recorded = 1;
                            }
                            y_end = ev.value;
                            y_values[y_index++] = ev.value;
                        }
                    } else if (ev.type == EV_KEY && ev.code == BTN_TOUCH) {
                        if (ev.value == 1) {
                            touch_start_time = get_current_time_ms();
                        } else if (ev.value == 0 && touch_start_time > 0) {
                            touch_end_time = get_current_time_ms();
                            long touch_duration = touch_end_time - touch_start_time;
                            int distance = abs(x_end - x_start) + abs(y_end - y_start);

                            if (touch_duration <= TAP_MAX_TIME && distance <= TAP_MAX_DISTANCE) {
                                valid_touch = 1;
                                break;
                            } else {
                                printf("Swipe detected. Retrying calibration for key '%c'.\n", keys[i]);
                                valid_touch = 0;
                                break;
                            }
                        }
                    }
                }
            }

            if (valid_touch) {
                if (x_index > 0 && y_index > 0) {
                    key_map[key_count].key = keys[i];
                    key_map[key_count].x = median(x_values, x_index);
                    key_map[key_count].y = median(y_values, y_index);
                    printf("Key '%c': x=%d, y=%d\n", keys[i], key_map[key_count].x, key_map[key_count].y);
                    key_count++;
                } else {
                    printf("No valid touches detected for key '%c'. Retrying.\n", keys[i]);
                }
            }
        }
    }
    printf("Calibration completed. Total keys calibrated: %d\n", key_count);
}

int calculate_euclidean_distance_squared(int x1, int y1, int x2, int y2) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    return dx * dx + dy * dy;
}

int find_closest_key(int x, int y) {
    int closest_key_index = -1;
    int min_distance = INT_MAX;

    printf("Finding closest key for coordinates: x=%d, y=%d\n", x, y);

    for (int i = 0; i < key_count; i++) {
        int distance = calculate_euclidean_distance_squared(x, y, key_map[i].x, key_map[i].y);
        printf("Checking key '%c': distance=%d, current min_distance=%d\n", key_map[i].key, distance, min_distance);
        if (distance < min_distance) {
            min_distance = distance;
            closest_key_index = i;
            printf("Key '%c' is currently the closest.\n", key_map[i].key);
        }
    }

    return closest_key_index != -1 ? closest_key_index : -1;
}

int get_mapped_keycode(int key_index, int *shift_required) {
    char key = key_map[key_index].key;

    *shift_required = 0;

    // Caps Lock should just send the keycode for Caps Lock
    if (key == 'c') {
        return KEY_CAPSLOCK;
    }

    // Toggle Num/Symbol mode
    if (key == 'n') {
        return KEY_NUMLOCK;
    }

    // Toggle keyboard enable/disable
    if (key == 't') {
        if (keyboard_enabled) {
            // Enable touchpad when disabling the keyboard
            enable_touchpad(touchpad_device_id);
        } else {
            // Disable touchpad when enabling the keyboard
            disable_touchpad(touchpad_device_id);
        }
        return KEY_LEFTCTRL;
    }

    if (num_symbols_mode) {
        // Handle special characters
        switch (key) {
            case 'A': *shift_required = 1; return KEY_1;    // !
            case 'B': *shift_required = 1; return KEY_2;    // @
            case 'C': *shift_required = 1; return KEY_3;    // #
            case 'D': *shift_required = 1; return KEY_4;    // $
            case 'E': *shift_required = 1; return KEY_5;    // %
            case 'F': *shift_required = 1; return KEY_6;    // ^
            case 'G': *shift_required = 1; return KEY_7;    // &
            case 'H': *shift_required = 1; return KEY_8;    // *
            case 'I': *shift_required = 1; return KEY_9;    // (
            case 'J': *shift_required = 1; return KEY_0;    // )
            case 'K': *shift_required = 1; return KEY_MINUS;    // _
            case 'L': *shift_required = 1; return KEY_EQUAL;    // +
            case 'M': *shift_required = 1; return KEY_LEFTBRACE; // {
            case 'N': *shift_required = 1; return KEY_RIGHTBRACE; // }
            case 'O': *shift_required = 1; return KEY_BACKSLASH; // |
            case 'P': return KEY_SEMICOLON; // :
            case 'Q': return KEY_APOSTROPHE; // "
            case 'R': return KEY_COMMA; // <
            case 'S': return KEY_DOT;   // >
            case 'T': return KEY_SLASH; // ?
            case 'U': return KEY_GRAVE;  // `
            case 'V': return KEY_MINUS;  // -
            case 'W': return KEY_EQUAL;  // =
            case 'X': return KEY_LEFTBRACE;  // [
            case 'Y': return KEY_RIGHTBRACE; // ]
            case 'Z': return KEY_BACKSLASH;  // \
            default: return KEY_UNKNOWN;
        }
    }

    // Default to the regular keycode
    return key_map[key_index].keycode;
}

void send_key_event(int fd, int keycode, int value) {
    struct input_event event;
    memset(&event, 0, sizeof(struct input_event));
    event.type = EV_KEY;
    event.code = keycode;
    event.value = value;
    write(fd, &event, sizeof(struct input_event));

    // Sync event
    memset(&event, 0, sizeof(struct input_event));
    event.type = EV_SYN;
    event.code = SYN_REPORT;
    event.value = 0;
    write(fd, &event, sizeof(struct input_event));
}

void enter_input_mode(FILE *fp, int fd) {
    struct input_event ev;
    int x_start = 0, y_start = 0;
    int x_end = 0, y_end = 0;
    long touch_start_time = 0, touch_end_time = 0;
    int keycode;
    int shift_required;
    int x_start_recorded = 0; // Indicates whether the initial x coordinate has been recorded
    int y_start_recorded = 0; // Indicates whether the initial y coordinate has been recorded

    printf("Entering input mode...\n");

    while (fread(&ev, sizeof(struct input_event), 1, fp) > 0) {
        if (ev.type == EV_ABS) {
            if (ev.code == ABS_X) {
                if (!x_start_recorded) {
                    x_start = ev.value;
                    x_start_recorded = 1;
                }
                x_end = ev.value;
                printf("X coordinate: %d\n", x_end);
            } else if (ev.code == ABS_Y) {
                if (!y_start_recorded) {
                    y_start = ev.value;
                    y_start_recorded = 1;
                }
                y_end = ev.value;
                printf("Y coordinate: %d\n", y_end);
            }
        } else if (ev.type == EV_KEY && ev.code == BTN_TOUCH) {
            if (ev.value == 1) {
                touch_start_time = get_current_time_ms();
                printf("Touch started at x=%d, y=%d\n", x_start, y_start);
            } else if (ev.value == 0 && touch_start_time > 0) {
                touch_end_time = get_current_time_ms();
                long touch_duration = touch_end_time - touch_start_time;

                int distance = calculate_euclidean_distance_squared(x_start, y_start, x_end, y_end);

                printf("Touch ended at x=%d, y=%d\n", x_end, y_end);
                printf("Touch duration: %ld ms, Distance: %d\n", touch_duration, distance);

                if (touch_duration <= TAP_MAX_TIME && distance <= TAP_MAX_DISTANCE * TAP_MAX_DISTANCE) {
                    int key_index = find_closest_key(x_end, y_end);
                    if (key_index != -1) {
                        char key = key_map[key_index].key;

                        if (key == 't') {
                            keyboard_enabled = !keyboard_enabled;
                            printf("Keyboard %s.\n", keyboard_enabled ? "enabled" : "disabled");

                            // Toggle touchpad based on keyboard_enabled state
                            if (keyboard_enabled) {
                                disable_touchpad(touchpad_device_id);
                            } else {
                                enable_touchpad(touchpad_device_id);
                            }
                        } else if (keyboard_enabled) {
                            if (key == 'c') {
                                keycode = get_mapped_keycode(key_index, &shift_required);
                                printf("Toggling Caps Lock, keycode %d\n", keycode);
                                send_key_event(fd, keycode, 1);
                                send_key_event(fd, keycode, 0);
                            } else if (key == 'n') {
                                num_symbols_mode = !num_symbols_mode;
                                printf("Numbers/Symbols mode %s.\n", num_symbols_mode ? "enabled" : "disabled");
                            } else {
                                keycode = get_mapped_keycode(key_index, &shift_required);

                                if (shift_required) {
                                    send_key_event(fd, KEY_LEFTSHIFT, 1);  // Press Shift
                                }

                                printf("Sending keycode %d for key '%c'\n", keycode, key);

                                // Send key press
                                send_key_event(fd, keycode, 1);

                                // Send key release
                                send_key_event(fd, keycode, 0);

                                if (shift_required) {
                                    send_key_event(fd, KEY_LEFTSHIFT, 0);  // Release Shift
                                }
                            }
                        }
                    } else {
                        printf("No key mapped to this touch.\n");
                    }
                } else {
                    printf("Touch was not a valid tap (swipe detected).\n");
                }

                touch_start_time = 0;
                x_start_recorded = 0;
                y_start_recorded = 0;
            }
        }
    }
}

int main() {
    char *device_name = NULL;
    char *device_path = load_device_path();
    int fd = -1;

    // Get touchpad device ID for xinput control
    touchpad_device_id = get_touchpad_device_id();
    if (touchpad_device_id == -1) {
        fprintf(stderr, "Failed to identify the touchpad device. Exiting...\n");
        return EXIT_FAILURE;
    }

    if (device_path == NULL) {
        printf("No saved device path found. Attempting to identify the touchpad device...\n");
        device_path = find_touchpad_device();

        if (device_path == NULL) {
            fprintf(stderr, "Failed to identify the touchpad device. Exiting...\n");
            return EXIT_FAILURE;
        }

        printf("Touchpad device identified: %s\n", device_path);
        save_device_path(device_path);
    }

    trim_whitespace(device_path);
    printf("Attempting to open device at path: '%s' with fopen()...\n", device_path);
    device_name = get_device_name(device_path);

    FILE *fp = fopen(device_path, "r");
    if (fp == NULL) {
        perror("Failed to open input device with fopen");
        return EXIT_FAILURE;
    }

    if (!check_calibration_file_exists()) {
        printf("Calibration data not found. Starting calibration...\n");
        calibrate_device(fp);
        save_calibration_data(device_name);
    } else {
        printf("Calibration data found. Loading and starting virtual keyboard...\n");
        load_calibration_data(&device_name);

        // Example initialization for a uinput device with extended keycodes

        fd = open("/dev/uinput", O_WRONLY | O_NONBLOCK);
        if (fd < 0) {
            perror("Failed to open /dev/uinput");
            fclose(fp);
            return EXIT_FAILURE;
        }

        // Enable key event types
        if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0) {
            perror("Failed to set EV_KEY");
            close(fd);
            fclose(fp);
            return EXIT_FAILURE;
        }

        // Enable all keycodes in the array
        for (int i = 0; i < sizeof(keycodes_to_enable) / sizeof(keycodes_to_enable[0]); i++) {
            if (ioctl(fd, UI_SET_KEYBIT, keycodes_to_enable[i]) < 0) {
                perror("Failed to set keybit");
                close(fd);
                fclose(fp);
                return EXIT_FAILURE;
            }
        }

        // Set up the uinput device
        struct uinput_setup usetup;
        memset(&usetup, 0, sizeof(usetup));
        usetup.id.bustype = BUS_USB;
        usetup.id.vendor  = 0x1234;
        usetup.id.product = 0x5678;
        strcpy(usetup.name, "Virtual Touchpad Keyboard");

        if (ioctl(fd, UI_DEV_SETUP, &usetup) < 0) {
            perror("Failed to setup uinput device");
            close(fd);
            fclose(fp);
            return EXIT_FAILURE;
        }

        if (ioctl(fd, UI_DEV_CREATE) < 0) {
            perror("Failed to create uinput device");
            close(fd);
            fclose(fp);
            return EXIT_FAILURE;
        }

        enter_input_mode(fp, fd);

        if (ioctl(fd, UI_DEV_DESTROY) < 0) {
            perror("Failed to destroy uinput device");
        }

        close(fd);
    }

    fclose(fp);
    free(device_name);
    free(device_path);
    printf("Program completed without segmentation faults.\n");
    return 0;
}
